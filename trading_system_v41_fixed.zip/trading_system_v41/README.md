# Trading System V4.1 — fix pack + animated dashboard

Эта версия собирает все найденные проблемы в один новый пакет:

- dedup по позициям и pending orders;
- cooldown по символам;
- netting противоположной стороны;
- TP1 / TP2 с переносом стопа в breakeven;
- отдельные fee на вход и выход;
- более жёсткие short-пороги;
- отключение слабых symbol+side комбинаций через конфиг;
- устойчивый API;
- новый дашборд с анимацией agent mesh;
- упрощённый запуск через `launcher_v41.sh`;
- demo-режим через `launcher_demo.sh`;
- smoke test для проверки логики без полной инфраструктуры.

## Что внутри

- `app/engine.py` — market data, signals, risk, execution
- `app/execution.py` — paper execution, partial TP, dedup, netting
- `app/api.py` — robust FastAPI backend
- `app/oracle.py` — local Ollama sidecar
- `ui/dashboard.html` — animated dashboard on pure JS
- `sql/clickhouse_schema.sql` — таблицы с suffix `v41` по умолчанию
- `scripts/smoke_test.py` — быстрый тест жизненного цикла позиции

## Быстрый запуск

### Вариант 1 — обычный запуск

```bash
cd ~/Documents/trading_system_v41
bash launcher_v41.sh
```

Что делает скрипт:

- создаёт `.venv`, если его нет;
- ставит зависимости;
- проверяет ClickHouse;
- инициализирует таблицы;
- стартует engine + api;
- стартует oracle только если `ENABLE_ORACLE=true` и Ollama реально доступна.

### Вариант 2 — demo-режим

```bash
cd ~/Documents/trading_system_v41
bash launcher_demo.sh
```

Этот режим поднимает систему в `MARKET_MODE=synthetic`, отключает oracle и использует отдельный `TABLE_SUFFIX=v41_demo`, чтобы быстрее увидеть сигналы и paper-trades.

## Перед полным запуском

```bash
cd ~/Documents/trading_system_v41
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/smoke_test.py
```

Ожидаемый результат:

```text
SMOKE TEST PASSED
```

## Ручной запуск компонентов

### Ollama
```bash
ollama serve
```

### ClickHouse
```bash
cd ~/clickhouse-test
./clickhouse server
```

### Система
```bash
cd ~/Documents/trading_system_v41
source .venv/bin/activate
export PYTHONPATH="$PWD"
bash launcher_v41.sh
```

## Проверка

```bash
curl http://127.0.0.1:8000/api/health | python3 -m json.tool
curl http://127.0.0.1:8000/api/portfolio | python3 -m json.tool
curl http://127.0.0.1:8000/api/open-positions | python3 -m json.tool
curl http://127.0.0.1:8000/api/recent-trades | python3 -m json.tool
```

## Логи

```bash
tail -f /tmp/v41_engine.log
tail -f /tmp/v41_oracle.log
tail -f /tmp/v41_api.log
```

## Что смотреть после запуска

- нет дублей одной и той же позиции;
- нет long+short одновременно по одному символу;
- есть `take_profit_1` и `take_profit_2`, а не только `stop`;
- частота сделок ниже, чем в старом агрессивном V4;
- дашборд не падает целиком, если один endpoint временно не отвечает.
