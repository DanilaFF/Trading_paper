from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List


def _env_list(name: str, default: str = "") -> List[str]:
    raw = os.getenv(name, default)
    return [item.strip().upper() for item in raw.split(",") if item.strip()]


def _env_map(name: str, default: str = "") -> Dict[str, float]:
    raw = os.getenv(name, default)
    result: Dict[str, float] = {}
    for item in raw.split(","):
        if not item.strip() or ":" not in item:
            continue
        key, value = item.split(":", 1)
        try:
            result[key.strip().upper()] = float(value.strip())
        except ValueError:
            continue
    return result


@dataclass(slots=True)
class Settings:
    clickhouse_host: str = os.getenv("CLICKHOUSE_HOST", "localhost")
    clickhouse_port: int = int(os.getenv("CLICKHOUSE_PORT", "8123"))
    clickhouse_user: str = os.getenv("CLICKHOUSE_USER", "default")
    clickhouse_password: str = os.getenv("CLICKHOUSE_PASSWORD", "")

    market_mode: str = os.getenv("MARKET_MODE", "live")
    binance_ws_base: str = os.getenv("BINANCE_WS_BASE", "wss://fstream.binance.com/stream?streams=")
    symbols: List[str] = field(default_factory=lambda: _env_list(
        "SYMBOLS",
        "BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT,XRPUSDT,DOGEUSDT,ADAUSDT,LINKUSDT,LTCUSDT,AVAXUSDT",
    ))
    feature_interval_seconds: float = float(os.getenv("FEATURE_INTERVAL_SECONDS", "1.0"))
    book_levels: int = int(os.getenv("BOOK_LEVELS", "20"))
    data_stale_after_seconds: float = float(os.getenv("DATA_STALE_AFTER_SECONDS", "3.0"))

    paper_deposit_usdt: float = float(os.getenv("PAPER_DEPOSIT_USDT", "10000"))
    risk_per_trade_pct: float = float(os.getenv("RISK_PER_TRADE_PCT", "0.006"))
    max_portfolio_leverage: float = float(os.getenv("MAX_PORTFOLIO_LEVERAGE", "3.5"))
    max_position_size_pct: float = float(os.getenv("MAX_POSITION_SIZE_PCT", "0.04"))
    max_open_positions: int = int(os.getenv("MAX_OPEN_POSITIONS", "6"))
    max_positions_per_symbol: int = int(os.getenv("MAX_POSITIONS_PER_SYMBOL", "1"))
    max_drawdown_pct: float = float(os.getenv("MAX_DRAWDOWN_PCT", "0.18"))
    min_leverage: float = float(os.getenv("MIN_LEVERAGE", "1.0"))
    max_leverage: float = float(os.getenv("MAX_LEVERAGE", "4.0"))
    kelly_fraction: float = float(os.getenv("KELLY_FRACTION", "0.25"))
    min_resolver_confidence: float = float(os.getenv("MIN_RESOLVER_CONFIDENCE", "0.52"))
    short_confidence_multiplier: float = float(os.getenv("SHORT_CONFIDENCE_MULTIPLIER", "1.12"))

    entry_style: str = os.getenv("ENTRY_STYLE", "taker")
    entry_order_ttl_seconds: float = float(os.getenv("ENTRY_ORDER_TTL_SECONDS", "5"))
    queue_ahead_multiplier: float = float(os.getenv("QUEUE_AHEAD_MULTIPLIER", "1.15"))
    entry_touch_buffer_bps: float = float(os.getenv("ENTRY_TOUCH_BUFFER_BPS", "0.35"))
    taker_slippage_bps: float = float(os.getenv("TAKER_SLIPPAGE_BPS", "6.0"))
    maker_slippage_bps: float = float(os.getenv("MAKER_SLIPPAGE_BPS", "1.2"))
    partial_fill_efficiency: float = float(os.getenv("PARTIAL_FILL_EFFICIENCY", "0.75"))
    entry_fee_bps: float = float(os.getenv("ENTRY_FEE_BPS", "6.0"))
    exit_fee_bps: float = float(os.getenv("EXIT_FEE_BPS", "6.0"))

    atr_lookback: int = int(os.getenv("ATR_LOOKBACK", "20"))
    atr_multiplier: float = float(os.getenv("ATR_MULTIPLIER", "1.9"))
    hurst_lookback: int = int(os.getenv("HURST_LOOKBACK", "100"))
    max_hold_seconds: int = int(os.getenv("MAX_HOLD_SECONDS", "1800"))
    tp1_r_multiple: float = float(os.getenv("TP1_R_MULTIPLE", "1.5"))
    tp2_r_multiple: float = float(os.getenv("TP2_R_MULTIPLE", "2.5"))
    tp1_close_fraction: float = float(os.getenv("TP1_CLOSE_FRACTION", "0.50"))
    move_stop_to_breakeven_after_tp1: bool = os.getenv("MOVE_STOP_TO_BREAKEVEN_AFTER_TP1", "true").lower() == "true"

    enable_netting: bool = os.getenv("ENABLE_NETTING", "true").lower() == "true"
    dedup_open_positions: bool = os.getenv("DEDUP_OPEN_POSITIONS", "true").lower() == "true"
    dedup_pending_orders: bool = os.getenv("DEDUP_PENDING_ORDERS", "true").lower() == "true"
    symbol_cooldown_default_seconds: float = float(os.getenv("SYMBOL_COOLDOWN_DEFAULT_SECONDS", "30"))
    symbol_cooldown_seconds: Dict[str, float] = field(default_factory=lambda: _env_map(
        "SYMBOL_COOLDOWN_SECONDS",
        "BTCUSDT:60,ETHUSDT:60,AVAXUSDT:45,LINKUSDT:45,SOLUSDT:45,DEFAULT:30",
    ))

    disabled_long_symbols: List[str] = field(default_factory=lambda: _env_list("DISABLED_LONG_SYMBOLS", "SOLUSDT,LINKUSDT"))
    disabled_short_symbols: List[str] = field(default_factory=lambda: _env_list("DISABLED_SHORT_SYMBOLS", "XRPUSDT,AVAXUSDT,LINKUSDT,BNBUSDT"))

    enable_oracle: bool = os.getenv("ENABLE_ORACLE", "true").lower() == "true"
    ollama_url: str = os.getenv("OLLAMA_URL", "http://localhost:11434/api/chat")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "qwen2.5:7b-instruct")
    oracle_interval_seconds: float = float(os.getenv("ORACLE_INTERVAL_SECONDS", "30"))

    api_host: str = os.getenv("API_HOST", "127.0.0.1")
    api_port: int = int(os.getenv("API_PORT", "8000"))
    dashboard_html: str = os.getenv("DASHBOARD_HTML", "ui/dashboard.html")
    table_suffix: str = os.getenv("TABLE_SUFFIX", "v41")

    @property
    def dashboard_path(self) -> Path:
        return Path(self.dashboard_html)

    def table(self, base: str) -> str:
        return f"{base}_{self.table_suffix}"

    def symbol_cooldown(self, symbol: str) -> float:
        symbol = symbol.upper()
        if symbol in self.symbol_cooldown_seconds:
            return self.symbol_cooldown_seconds[symbol]
        if "DEFAULT" in self.symbol_cooldown_seconds:
            return self.symbol_cooldown_seconds["DEFAULT"]
        return self.symbol_cooldown_default_seconds

    def side_allowed(self, symbol: str, side: str) -> bool:
        symbol = symbol.upper()
        side = side.lower()
        if side == "long" and symbol in self.disabled_long_symbols:
            return False
        if side == "short" and symbol in self.disabled_short_symbols:
            return False
        return True


settings = Settings()
