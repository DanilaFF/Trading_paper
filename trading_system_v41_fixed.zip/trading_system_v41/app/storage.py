from __future__ import annotations

from pathlib import Path
from typing import Iterable, Sequence

import clickhouse_connect

from .config import settings


def get_client():
    return clickhouse_connect.get_client(
        host=settings.clickhouse_host,
        port=settings.clickhouse_port,
        username=settings.clickhouse_user,
        password=settings.clickhouse_password,
    )


def load_schema_sql() -> str:
    root = Path(__file__).resolve().parents[1]
    raw = (root / "sql" / "clickhouse_schema.sql").read_text(encoding="utf-8")
    return raw.format(suffix=settings.table_suffix)


def init_schema(check_only: bool = False) -> None:
    client = get_client()
    client.query("SELECT 1")
    if check_only:
        return
    sql = load_schema_sql()
    for statement in [s.strip() for s in sql.split(";") if s.strip()]:
        client.command(statement)


def insert_rows(table: str, rows: Iterable[Sequence], column_names: Sequence[str]) -> None:
    rows = list(rows)
    if not rows:
        return
    client = get_client()
    client.insert(table, rows, column_names=column_names)
