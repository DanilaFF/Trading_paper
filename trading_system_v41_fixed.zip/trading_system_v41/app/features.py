from __future__ import annotations

import math
import statistics
from typing import Iterable, List, Tuple

import numpy as np

from .config import settings
from .schemas import FeatureSnapshot, SymbolState


def _safe_div(numerator: float, denominator: float, default: float = 0.0) -> float:
    if abs(denominator) < 1e-12:
        return default
    return numerator / denominator


def calculate_atr(prices: List[float], lookback: int | None = None) -> float:
    lookback = lookback or settings.atr_lookback
    if len(prices) < lookback + 1:
        return 0.0
    recent = prices[-(lookback + 1):]
    trs = [abs(recent[i] - recent[i - 1]) for i in range(1, len(recent))]
    return float(sum(trs) / len(trs)) if trs else 0.0


def calculate_realized_vol(prices: List[float], lookback: int = 40) -> float:
    if len(prices) < lookback + 1:
        return 0.0
    recent = prices[-(lookback + 1):]
    returns = np.diff(np.log(np.maximum(recent, 1e-9)))
    if len(returns) == 0:
        return 0.0
    return float(np.std(returns) * math.sqrt(len(returns)))


def calculate_hurst(prices: List[float], lookback: int | None = None) -> float:
    lookback = lookback or settings.hurst_lookback
    if len(prices) < lookback:
        return 0.5
    series = np.asarray(prices[-lookback:], dtype=float)
    if np.any(series <= 0):
        return 0.5
    returns = np.diff(np.log(series))
    if len(returns) < 20:
        return 0.5
    lags = range(2, min(20, len(returns) // 2))
    tau = []
    lag_vals = []
    for lag in lags:
        diff = returns[lag:] - returns[:-lag]
        if len(diff) < 2:
            continue
        std = np.std(diff)
        if std <= 0:
            continue
        tau.append(std)
        lag_vals.append(lag)
    if len(tau) < 2:
        return 0.5
    poly = np.polyfit(np.log(lag_vals), np.log(tau), 1)
    hurst = poly[0] * 2.0
    return float(max(0.0, min(hurst, 1.0)))


def detect_regime(hurst: float) -> str:
    if hurst >= 0.60:
        return "TRENDING"
    if hurst <= 0.40:
        return "MEAN_REVERT"
    return "NEUTRAL"


def summarize_trade_flow(state: SymbolState, seconds: float = 6.0) -> Tuple[float, float, float, float]:
    trades = state.trade_window
    if not trades:
        return 0.0, 0.0, 0.0, 0.0
    buy_qty = sum(t.qty for t in trades if t.side == "buy_taker")
    sell_qty = sum(t.qty for t in trades if t.side == "sell_taker")
    total = buy_qty + sell_qty
    signed = buy_qty - sell_qty
    imbalance = _safe_div(signed, total, 0.0)
    qtys = [t.qty for t in trades]
    median_qty = statistics.median(qtys) if qtys else 0.0
    sweeps = [t.qty for t in trades if median_qty > 0 and t.qty >= median_qty * 4.0]
    sweep_score = min(sum(sweeps) / (total + 1e-9), 1.0) if total > 0 else 0.0
    return buy_qty, sell_qty, imbalance, sweep_score


def compute_feature_snapshot(symbol: str, state: SymbolState, ts: str, now_mono: float) -> FeatureSnapshot | None:
    if not state.bids or not state.asks:
        return None

    best_bid = max(state.bids)
    best_ask = min(state.asks)
    if best_ask <= best_bid or best_bid <= 0:
        return None

    mid = (best_bid + best_ask) / 2.0
    spread_bps = ((best_ask - best_bid) / mid) * 10_000.0

    top_bids = sorted(state.bids.items(), key=lambda kv: kv[0], reverse=True)[: settings.book_levels]
    top_asks = sorted(state.asks.items(), key=lambda kv: kv[0])[: settings.book_levels]

    bid_qty_top = float(sum(q for _, q in top_bids))
    ask_qty_top = float(sum(q for _, q in top_asks))
    total_top = bid_qty_top + ask_qty_top
    imbalance = bid_qty_top / total_top if total_top > 0 else 0.5

    wall_bid_share = max((q for _, q in top_bids), default=0.0) / bid_qty_top if bid_qty_top > 0 else 0.0
    wall_ask_share = max((q for _, q in top_asks), default=0.0) / ask_qty_top if ask_qty_top > 0 else 0.0

    def _depth_slope(levels: Iterable[tuple[float, float]], side: str) -> float:
        levels = list(levels)
        if len(levels) < 3:
            return 0.0
        distances = []
        quantities = []
        for price, qty in levels:
            dist = abs((price - mid) / mid) * 10_000.0
            distances.append(max(dist, 0.0001))
            quantities.append(max(qty, 1e-9))
        x = np.log(np.asarray(distances))
        y = np.log(np.asarray(quantities))
        slope = np.polyfit(x, y, 1)[0]
        return float(slope)

    depth_slope = (_depth_slope(top_bids, "bid") + _depth_slope(top_asks, "ask")) / 2.0

    bid_top_1 = top_bids[0][1] if top_bids else 0.0
    ask_top_1 = top_asks[0][1] if top_asks else 0.0
    refill_ratio = ((bid_top_1 - state.last_refill_bid) + (ask_top_1 - state.last_refill_ask)) / (bid_top_1 + ask_top_1 + 1e-9)
    depletion_ratio = -refill_ratio
    state.last_refill_bid = bid_top_1
    state.last_refill_ask = ask_top_1

    buy_qty, sell_qty, trade_imbalance, sweep_score = summarize_trade_flow(state)
    signed_volume = buy_qty - sell_qty
    toxicity = min(1.0, abs(trade_imbalance) * 0.65 + sweep_score * 0.35)

    atr = calculate_atr(state.price_history)
    realized_vol = calculate_realized_vol(state.price_history)
    hurst = calculate_hurst(state.price_history)
    regime = detect_regime(hurst)

    stale = 1 if (now_mono - state.updated_monotonic) > settings.data_stale_after_seconds else 0

    return FeatureSnapshot(
        ts=ts,
        symbol=symbol,
        mid=mid,
        best_bid=best_bid,
        best_ask=best_ask,
        bid_qty_top=bid_qty_top,
        ask_qty_top=ask_qty_top,
        spread_bps=spread_bps,
        imbalance=imbalance,
        wall_bid_share=wall_bid_share,
        wall_ask_share=wall_ask_share,
        depth_slope=depth_slope,
        refill_ratio=refill_ratio,
        depletion_ratio=depletion_ratio,
        trade_imbalance=trade_imbalance,
        signed_volume=signed_volume,
        toxicity=toxicity,
        sweep_score=sweep_score,
        atr=atr,
        realized_vol=realized_vol,
        hurst=hurst,
        regime=regime,
        aggress_buy_qty=buy_qty,
        aggress_sell_qty=sell_qty,
        stale=stale,
    )
