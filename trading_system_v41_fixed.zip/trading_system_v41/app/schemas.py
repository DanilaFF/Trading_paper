from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass(slots=True)
class TradePrint:
    ts: str
    price: float
    qty: float
    side: str  # buy_taker or sell_taker


@dataclass(slots=True)
class FeatureSnapshot:
    ts: str
    symbol: str
    mid: float
    best_bid: float
    best_ask: float
    bid_qty_top: float
    ask_qty_top: float
    spread_bps: float
    imbalance: float
    wall_bid_share: float
    wall_ask_share: float
    depth_slope: float
    refill_ratio: float
    depletion_ratio: float
    trade_imbalance: float
    signed_volume: float
    toxicity: float
    sweep_score: float
    atr: float
    realized_vol: float
    hurst: float
    regime: str
    aggress_buy_qty: float
    aggress_sell_qty: float
    stale: int = 0


@dataclass(slots=True)
class AgentVote:
    ts: str
    symbol: str
    agent: str
    vote: str
    score: float
    reason: str
    diagnostics_json: str = "{}"


@dataclass(slots=True)
class ResolverSignal:
    ts: str
    signal_id: str
    symbol: str
    action: str
    confidence: float
    long_score: float
    short_score: float
    reason: str
    regime: str
    hurst: float
    mid: float
    risk_state: str = "ok"


@dataclass(slots=True)
class PaperOrder:
    ts: str
    order_id: str
    signal_id: str
    symbol: str
    side: str
    intent: str
    limit_price: float
    qty: float
    leverage: float
    notional_usdt: float
    state: str
    filled_qty: float = 0.0
    avg_fill_price: float = 0.0
    queue_ahead_qty: float = 0.0
    ttl_seconds: float = 0.0
    created_monotonic: float = 0.0
    last_fill_monotonic: float = 0.0
    reason: str = ""


@dataclass(slots=True)
class Position:
    ts: str
    position_id: str
    signal_id: str
    symbol: str
    side: str
    qty: float
    leverage: float
    entry_price: float
    mark_price: float
    notional_usdt: float
    unrealized_pnl_usdt: float
    stop_price: float
    take_profit_price: float
    trailing_stop_price: float
    regime: str
    status: str
    opened_monotonic: float = 0.0
    entry_reason: str = ""
    initial_qty: float = 0.0
    initial_notional_usdt: float = 0.0
    remaining_entry_fee_usdt: float = 0.0
    tp1_price: float = 0.0
    tp2_price: float = 0.0
    tp1_done: bool = False
    tp1_close_fraction: float = 0.5


@dataclass(slots=True)
class PortfolioState:
    ts: str
    balance_usdt: float
    realized_pnl_usdt: float
    total_leverage: float
    open_positions: int
    drawdown_pct: float
    win_rate: float
    avg_win_usdt: float
    avg_loss_usdt: float
    pending_orders: int


@dataclass(slots=True)
class OracleNote:
    ts: str
    symbol: str
    note_type: str
    signal_id: str
    recommendation: str
    confidence: float
    analysis: str
    model: str
    tokens_used: int
    ollama_latency_ms: int


@dataclass(slots=True)
class SystemEvent:
    ts: str
    level: str
    component: str
    event_type: str
    symbol: str
    details: str


@dataclass(slots=True)
class SymbolState:
    symbol: str
    bids: Dict[float, float] = field(default_factory=dict)
    asks: Dict[float, float] = field(default_factory=dict)
    price_history: List[float] = field(default_factory=list)
    trade_window: List[TradePrint] = field(default_factory=list)
    buy_aggressor_window: float = 0.0
    sell_aggressor_window: float = 0.0
    last_refill_bid: float = 0.0
    last_refill_ask: float = 0.0
    updated_monotonic: float = 0.0
    last_mid: Optional[float] = None
