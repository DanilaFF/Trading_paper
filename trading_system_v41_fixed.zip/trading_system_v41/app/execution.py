from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from .config import settings
from .schemas import FeatureSnapshot, PaperOrder, Position, ResolverSignal, SystemEvent
from .risk import RiskDecision


def _slippage_bps(intent: str) -> float:
    return settings.maker_slippage_bps if intent == "maker" else settings.taker_slippage_bps


def _fee_usdt(notional: float, fee_bps: float) -> float:
    return float(notional) * float(fee_bps) / 10_000.0


@dataclass(slots=True)
class ExecutionUpdate:
    order_rows: List[list] = field(default_factory=list)
    fill_rows: List[list] = field(default_factory=list)
    position_rows: List[list] = field(default_factory=list)
    trade_rows: List[list] = field(default_factory=list)
    events: List[SystemEvent] = field(default_factory=list)


@dataclass(slots=True)
class PreEntryDecision:
    allow_submit: bool
    update: ExecutionUpdate


@dataclass(slots=True)
class PaperExecution:
    pending_orders: Dict[str, PaperOrder] = field(default_factory=dict)
    positions: Dict[str, Position] = field(default_factory=dict)
    balance_usdt: float = settings.paper_deposit_usdt
    realized_pnl_usdt: float = 0.0
    symbol_cooldown_until: Dict[str, float] = field(default_factory=dict)

    def active_positions_for(self, symbol: str, side: str | None = None) -> List[Position]:
        rows = [p for p in self.positions.values() if p.symbol == symbol and p.status == "OPEN"]
        if side:
            rows = [p for p in rows if p.side == side]
        return rows

    def pending_orders_for(self, symbol: str, side: str | None = None) -> List[PaperOrder]:
        rows = [o for o in self.pending_orders.values() if o.symbol == symbol and o.state in {"NEW", "PARTIAL"}]
        if side:
            rows = [o for o in rows if o.side == side]
        return rows

    def pre_entry_check(self, signal: ResolverSignal, feat: FeatureSnapshot) -> PreEntryDecision:
        ts = feat.ts
        now_mono = time.monotonic()
        update = ExecutionUpdate()
        symbol = signal.symbol
        side = signal.action
        opposite = "short" if side == "long" else "long"

        cooldown_until = self.symbol_cooldown_until.get(symbol, 0.0)
        if now_mono < cooldown_until:
            update.events.append(SystemEvent(ts, "INFO", "execution", "signal_skipped", symbol, "symbol_cooldown_active"))
            return PreEntryDecision(False, update)

        if settings.dedup_open_positions and self.active_positions_for(symbol, side):
            update.events.append(SystemEvent(ts, "INFO", "execution", "signal_skipped", symbol, "same_side_open_exists"))
            return PreEntryDecision(False, update)

        if settings.dedup_pending_orders and self.pending_orders_for(symbol, side):
            update.events.append(SystemEvent(ts, "INFO", "execution", "signal_skipped", symbol, "same_side_pending_exists"))
            return PreEntryDecision(False, update)

        if settings.enable_netting:
            had_netting = False
            for order in list(self.pending_orders_for(symbol, opposite)):
                order.state = "CANCELED"
                update.order_rows.append(self._record_order_row(order, ts))
                update.events.append(SystemEvent(ts, "INFO", "execution", "netting_cancel_pending", symbol, order.order_id))
                del self.pending_orders[order.order_id]
                had_netting = True
            for position in list(self.active_positions_for(symbol, opposite)):
                trade_row, pos_row, event = self._close_position(position, feat, ts, "netting_flip")
                update.trade_rows.append(trade_row)
                update.position_rows.append(pos_row)
                update.events.append(event)
                del self.positions[position.position_id]
                had_netting = True
            if had_netting:
                self.symbol_cooldown_until[symbol] = now_mono + min(5.0, settings.symbol_cooldown(symbol) / 6.0)
                update.events.append(SystemEvent(ts, "INFO", "execution", "signal_skipped", symbol, "netting_executed_skip_same_cycle"))
                return PreEntryDecision(False, update)

        return PreEntryDecision(True, update)

    def submit_order(self, signal: ResolverSignal, feat: FeatureSnapshot, risk: RiskDecision) -> tuple[PaperOrder, SystemEvent]:
        now_mono = time.monotonic()
        side = signal.action
        if side == "long":
            limit_price = feat.best_bid if settings.entry_style == "maker" else feat.best_ask
            queue_ahead_qty = 0.0 if settings.entry_style == "taker" else feat.bid_qty_top * settings.queue_ahead_multiplier / max(settings.book_levels, 1)
        else:
            limit_price = feat.best_ask if settings.entry_style == "maker" else feat.best_bid
            queue_ahead_qty = 0.0 if settings.entry_style == "taker" else feat.ask_qty_top * settings.queue_ahead_multiplier / max(settings.book_levels, 1)

        order = PaperOrder(
            ts=feat.ts,
            order_id=str(uuid.uuid4()),
            signal_id=signal.signal_id,
            symbol=signal.symbol,
            side=side,
            intent=settings.entry_style,
            limit_price=limit_price,
            qty=risk.qty,
            leverage=risk.leverage,
            notional_usdt=risk.notional_usdt,
            state="NEW",
            queue_ahead_qty=queue_ahead_qty,
            ttl_seconds=settings.entry_order_ttl_seconds,
            created_monotonic=now_mono,
            last_fill_monotonic=now_mono,
            reason=signal.reason,
        )
        self.pending_orders[order.order_id] = order
        event = SystemEvent(feat.ts, "INFO", "execution", "order_created", feat.symbol, f"{order.side} {order.qty:.6f}@{order.limit_price:.4f}")
        return order, event

    def _record_order_row(self, order: PaperOrder, ts: str) -> list:
        return [
            ts,
            order.order_id,
            order.signal_id,
            order.symbol,
            order.side,
            order.intent,
            float(order.limit_price),
            float(order.qty),
            float(order.leverage),
            float(order.notional_usdt),
            order.state,
            float(order.filled_qty),
            float(order.avg_fill_price),
            float(order.queue_ahead_qty),
            float(order.ttl_seconds),
            order.reason,
        ]

    def _record_position_row(self, position: Position, ts: str) -> list:
        return [
            ts,
            position.position_id,
            position.symbol,
            position.side,
            float(position.qty),
            float(position.leverage),
            float(position.entry_price),
            float(position.mark_price),
            float(position.notional_usdt),
            float(position.unrealized_pnl_usdt),
            float(position.stop_price),
            float(position.take_profit_price),
            float(position.trailing_stop_price),
            position.regime,
            position.status,
            position.entry_reason,
        ]

    def process_symbol(self, feat: FeatureSnapshot, risk_decisions: Dict[str, RiskDecision]) -> ExecutionUpdate:
        ts = feat.ts
        now_mono = time.monotonic()
        update = ExecutionUpdate()

        relevant_orders = [o for o in self.pending_orders.values() if o.symbol == feat.symbol and o.state in {"NEW", "PARTIAL"}]
        for order in relevant_orders:
            time_live = now_mono - order.created_monotonic
            if time_live > order.ttl_seconds:
                order.state = "CANCELED"
                update.order_rows.append(self._record_order_row(order, ts))
                update.events.append(SystemEvent(ts, "WARN", "execution", "order_canceled_ttl", feat.symbol, order.order_id))
                del self.pending_orders[order.order_id]
                continue

            if order.intent == "taker":
                if time_live < 0.05:
                    continue
                fill_qty = order.qty - order.filled_qty
                if fill_qty <= 0:
                    continue
                fill_price = feat.best_ask * (1.0 + _slippage_bps(order.intent) / 10_000.0) if order.side == "long" else feat.best_bid * (1.0 - _slippage_bps(order.intent) / 10_000.0)
                order.filled_qty = order.qty
                order.avg_fill_price = fill_price
                order.state = "FILLED"
                update.fill_rows.append([ts, order.order_id, order.signal_id, order.symbol, order.side, float(fill_price), float(fill_qty), order.intent, float(_slippage_bps(order.intent))])
                update.order_rows.append(self._record_order_row(order, ts))
                update.events.append(SystemEvent(ts, "INFO", "execution", "order_filled", feat.symbol, f"{order.order_id}:{fill_qty:.6f}"))
                position = self._open_position_from_order(order, feat, risk_decisions.get(order.signal_id))
                self.positions[position.position_id] = position
                self.symbol_cooldown_until[order.symbol] = now_mono + settings.symbol_cooldown(order.symbol)
                update.position_rows.append(self._record_position_row(position, ts))
                del self.pending_orders[order.order_id]
                continue

            touch_buffer = feat.mid * (settings.entry_touch_buffer_bps / 10_000.0)
            if order.side == "long":
                book_touch = feat.best_bid + touch_buffer >= order.limit_price
                against_flow = feat.aggress_sell_qty
            else:
                book_touch = feat.best_ask - touch_buffer <= order.limit_price
                against_flow = feat.aggress_buy_qty

            if not book_touch or against_flow <= 0:
                continue

            available = max(0.0, against_flow * settings.partial_fill_efficiency)
            still_behind = max(0.0, order.queue_ahead_qty - available)
            fillable = max(0.0, available - order.queue_ahead_qty)
            order.queue_ahead_qty = still_behind
            if fillable <= 0:
                continue

            remaining = order.qty - order.filled_qty
            fill_qty = min(remaining, fillable)
            if fill_qty <= 0:
                continue

            fill_price = order.limit_price * (1.0 + (_slippage_bps(order.intent) / 10_000.0 if order.side == "long" else -_slippage_bps(order.intent) / 10_000.0))
            prev_notional = order.avg_fill_price * order.filled_qty
            order.filled_qty += fill_qty
            order.avg_fill_price = (prev_notional + fill_price * fill_qty) / max(order.filled_qty, 1e-9)
            order.state = "FILLED" if order.filled_qty >= order.qty * 0.999 else "PARTIAL"
            update.fill_rows.append([ts, order.order_id, order.signal_id, order.symbol, order.side, float(fill_price), float(fill_qty), order.intent, float(_slippage_bps(order.intent))])
            update.order_rows.append(self._record_order_row(order, ts))
            update.events.append(SystemEvent(ts, "INFO", "execution", "order_filled" if order.state == "FILLED" else "order_partial_fill", feat.symbol, f"{order.order_id}:{fill_qty:.6f}"))

            if order.state == "FILLED":
                position = self._open_position_from_order(order, feat, risk_decisions.get(order.signal_id))
                self.positions[position.position_id] = position
                self.symbol_cooldown_until[order.symbol] = now_mono + settings.symbol_cooldown(order.symbol)
                update.position_rows.append(self._record_position_row(position, ts))
                del self.pending_orders[order.order_id]

        for position in [p for p in self.positions.values() if p.symbol == feat.symbol and p.status == "OPEN"]:
            position.mark_price = feat.mid
            gross = (feat.mid - position.entry_price) * position.qty if position.side == "long" else (position.entry_price - feat.mid) * position.qty
            position.unrealized_pnl_usdt = gross * position.leverage

            if position.side == "long":
                new_trailing = feat.mid - max(feat.atr, feat.mid * 0.0015) * settings.atr_multiplier
                position.trailing_stop_price = max(position.trailing_stop_price, new_trailing)
            else:
                new_trailing = feat.mid + max(feat.atr, feat.mid * 0.0015) * settings.atr_multiplier
                position.trailing_stop_price = min(position.trailing_stop_price, new_trailing) if position.trailing_stop_price > 0 else new_trailing

            if not position.tp1_done:
                hit_tp1 = feat.mid >= position.tp1_price if position.side == "long" else feat.mid <= position.tp1_price
                if hit_tp1:
                    partial_qty = max(position.qty * position.tp1_close_fraction, 0.0)
                    if partial_qty > 0 and partial_qty < position.qty:
                        trade_row, event = self._partial_close(position, feat, ts, partial_qty, "take_profit_1")
                        update.trade_rows.append(trade_row)
                        update.events.append(event)
                        if settings.move_stop_to_breakeven_after_tp1:
                            position.stop_price = position.entry_price
                            position.trailing_stop_price = position.entry_price
                        position.take_profit_price = position.tp2_price
                        position.tp1_done = True

            should_close = None
            tp_target = position.tp2_price if position.tp1_done else position.tp2_price
            if position.side == "long":
                if feat.mid <= max(position.stop_price, position.trailing_stop_price):
                    should_close = "stop"
                elif feat.mid >= tp_target:
                    should_close = "take_profit_2" if position.tp1_done else "take_profit"
            else:
                if feat.mid >= min(position.stop_price, position.trailing_stop_price):
                    should_close = "stop"
                elif feat.mid <= tp_target:
                    should_close = "take_profit_2" if position.tp1_done else "take_profit"

            if not should_close and (now_mono - position.opened_monotonic) >= settings.max_hold_seconds:
                should_close = "time_stop"
            if not should_close and feat.toxicity >= 0.84:
                should_close = "toxicity_exit"

            if should_close:
                trade_row, pos_row, event = self._close_position(position, feat, ts, should_close)
                update.trade_rows.append(trade_row)
                update.position_rows.append(pos_row)
                update.events.append(event)
                del self.positions[position.position_id]
            else:
                update.position_rows.append(self._record_position_row(position, ts))

        return update

    def _open_position_from_order(self, order: PaperOrder, feat: FeatureSnapshot, risk: RiskDecision | None) -> Position:
        stop_price = risk.stop_price if risk else feat.mid * (0.99 if order.side == "long" else 1.01)
        tp1_price = risk.tp1_price if risk else feat.mid * (1.01 if order.side == "long" else 0.99)
        tp2_price = risk.tp2_price if risk else feat.mid * (1.02 if order.side == "long" else 0.98)
        trailing = stop_price
        entry_price = order.avg_fill_price or order.limit_price
        entry_fee = _fee_usdt(order.notional_usdt, settings.entry_fee_bps)
        return Position(
            ts=feat.ts,
            position_id=str(uuid.uuid4()),
            signal_id=order.signal_id,
            symbol=order.symbol,
            side=order.side,
            qty=order.qty,
            leverage=order.leverage,
            entry_price=entry_price,
            mark_price=feat.mid,
            notional_usdt=order.notional_usdt,
            unrealized_pnl_usdt=0.0,
            stop_price=stop_price,
            take_profit_price=tp2_price,
            trailing_stop_price=trailing,
            regime=feat.regime,
            status="OPEN",
            opened_monotonic=time.monotonic(),
            entry_reason=order.reason,
            initial_qty=order.qty,
            initial_notional_usdt=order.notional_usdt,
            remaining_entry_fee_usdt=entry_fee,
            tp1_price=tp1_price,
            tp2_price=tp2_price,
            tp1_done=False,
            tp1_close_fraction=settings.tp1_close_fraction,
        )

    def _partial_close(self, position: Position, feat: FeatureSnapshot, ts: str, close_qty: float, reason: str) -> tuple[list, SystemEvent]:
        close_qty = min(close_qty, position.qty)
        gross, exit_price, close_notional = self._close_math(position, feat, close_qty)
        entry_fee_share = position.remaining_entry_fee_usdt * (close_qty / max(position.qty, 1e-9))
        exit_fee = _fee_usdt(close_notional, settings.exit_fee_bps)
        net = gross - entry_fee_share - exit_fee
        self.realized_pnl_usdt += net

        position.qty -= close_qty
        position.notional_usdt = max(position.initial_notional_usdt * (position.qty / max(position.initial_qty, 1e-9)), 0.0)
        position.remaining_entry_fee_usdt = max(position.remaining_entry_fee_usdt - entry_fee_share, 0.0)
        position.mark_price = exit_price
        position.unrealized_pnl_usdt = 0.0

        hold_seconds = time.monotonic() - position.opened_monotonic
        trade_row = [
            ts,
            str(uuid.uuid4()),
            position.position_id,
            position.symbol,
            position.side,
            float(position.entry_price),
            float(exit_price),
            float(close_qty),
            float(position.leverage),
            float(gross),
            float(net),
            reason,
            float(hold_seconds),
        ]
        event = SystemEvent(ts, "INFO", "execution", "position_scaled_out", position.symbol, f"{reason} pnl={net:.2f} qty={close_qty:.6f}")
        return trade_row, event

    def _close_math(self, position: Position, feat: FeatureSnapshot, close_qty: float) -> Tuple[float, float, float]:
        slip_bps = settings.taker_slippage_bps
        if position.side == "long":
            exit_price = feat.best_bid * (1.0 - slip_bps / 10_000.0)
            gross = (exit_price - position.entry_price) * close_qty * position.leverage
        else:
            exit_price = feat.best_ask * (1.0 + slip_bps / 10_000.0)
            gross = (position.entry_price - exit_price) * close_qty * position.leverage
        close_notional = exit_price * close_qty
        return gross, exit_price, close_notional

    def _close_position(self, position: Position, feat: FeatureSnapshot, ts: str, reason: str) -> tuple[list, list, SystemEvent]:
        close_qty = position.qty
        gross, exit_price, close_notional = self._close_math(position, feat, close_qty)
        entry_fee_share = position.remaining_entry_fee_usdt
        exit_fee = _fee_usdt(close_notional, settings.exit_fee_bps)
        net = gross - entry_fee_share - exit_fee
        self.realized_pnl_usdt += net

        position.mark_price = exit_price
        position.unrealized_pnl_usdt = 0.0
        position.qty = close_qty
        position.remaining_entry_fee_usdt = 0.0
        position.status = "CLOSED"

        hold_seconds = time.monotonic() - position.opened_monotonic
        trade_id = str(uuid.uuid4())
        trade_row = [
            ts,
            trade_id,
            position.position_id,
            position.symbol,
            position.side,
            float(position.entry_price),
            float(exit_price),
            float(close_qty),
            float(position.leverage),
            float(gross),
            float(net),
            reason,
            float(hold_seconds),
        ]
        pos_row = self._record_position_row(position, ts)
        event = SystemEvent(ts, "INFO", "execution", "position_closed", position.symbol, f"{reason} pnl={net:.2f}")
        return trade_row, pos_row, event
