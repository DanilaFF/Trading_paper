from __future__ import annotations

import asyncio
import json
import math
import random
import time
from datetime import datetime, timezone
from typing import Dict

import websockets

from .agents import generate_votes
from .config import settings
from .execution import PaperExecution
from .features import compute_feature_snapshot
from .resolver import Resolver
from .risk import RiskDecision, RiskManager
from .schemas import SymbolState, SystemEvent
from .storage import init_schema, insert_rows


def iso_ts() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


class TradingEngine:
    def __init__(self) -> None:
        self.symbol_states: Dict[str, SymbolState] = {symbol: SymbolState(symbol=symbol) for symbol in settings.symbols}
        self.resolver = Resolver(cooldown_seconds=10.0)
        self.synthetic_phase_by_symbol: Dict[str, float] = {symbol: (idx * 0.9) for idx, symbol in enumerate(settings.symbols)}
        self.risk = RiskManager()
        self.execution = PaperExecution()
        self.running = True
        self.pending_risk: Dict[str, RiskDecision] = {}

    async def run(self) -> None:
        init_schema()
        await asyncio.gather(self._market_task(), self._feature_loop())

    async def _market_task(self) -> None:
        if settings.market_mode.lower() == "synthetic":
            await self._synthetic_market_loop()
        else:
            await self._live_market_loop()

    async def _live_market_loop(self) -> None:
        streams = []
        for symbol in settings.symbols:
            s = symbol.lower()
            streams.append(f"{s}@depth20@100ms")
            streams.append(f"{s}@aggTrade")
        url = settings.binance_ws_base + "/".join(streams)

        while self.running:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_queue=4096) as ws:
                    self._event("INFO", "engine", "ws_connected", "", url)
                    async for raw in ws:
                        msg = json.loads(raw)
                        data = msg.get("data", {})
                        stream = msg.get("stream", "")
                        if "@depth" in stream:
                            self._handle_depth(data)
                        elif "@aggTrade" in stream:
                            self._handle_trade(data)
            except Exception as exc:
                self._event("ERROR", "engine", "ws_error", "", repr(exc))
                await asyncio.sleep(2)

    async def _synthetic_market_loop(self) -> None:
        seeds = {symbol: 100 + i * 15 for i, symbol in enumerate(settings.symbols)}
        while self.running:
            now = time.time()
            for symbol, state in self.symbol_states.items():
                base = seeds[symbol]
                phase = self.synthetic_phase_by_symbol.get(symbol, 0.0)
                bias = math.sin(now / 5.5 + phase)
                micro_trend = math.sin(now / 17.0 + phase * 0.7) * 0.0007
                px = (state.last_mid or base) * (1 + micro_trend + bias * 0.00045 + random.uniform(-0.00018, 0.00018))

                spread_bps = 1.4 + (abs(bias) * 0.8)
                spread_frac = spread_bps / 20_000.0
                bid = px * (1.0 - spread_frac)
                ask = px * (1.0 + spread_frac)

                bid_bias = max(0.0, bias)
                ask_bias = max(0.0, -bias)
                bids = {}
                asks = {}
                for i in range(settings.book_levels):
                    level_shift = 1.0 - i * 0.00008
                    ask_shift = 1.0 + i * 0.00008
                    level_weight = max(0.25, 1.0 - i * 0.05)
                    bid_qty = random.uniform(18, 72) * (1.0 + bid_bias * 1.7 * level_weight)
                    ask_qty = random.uniform(18, 72) * (1.0 + ask_bias * 1.7 * level_weight)
                    bids[round(bid * level_shift, 4)] = bid_qty
                    asks[round(ask * ask_shift, 4)] = ask_qty
                state.bids = bids
                state.asks = asks
                state.updated_monotonic = time.monotonic()
                state.last_mid = px
                state.price_history.append(px)
                if len(state.price_history) > 500:
                    state.price_history = state.price_history[-500:]

                trade_burst = 3 if abs(bias) > 0.35 else 2
                for _ in range(trade_burst):
                    buy_prob = min(max(0.50 + bias * 0.42, 0.05), 0.95)
                    aggress_side = "buy_taker" if random.random() < buy_prob else "sell_taker"
                    qty = random.uniform(2.0, 16.0) * (1.0 + abs(bias) * 1.2)
                    state.trade_window.append(type("TP", (), {"ts": iso_ts(), "price": px, "qty": qty, "side": aggress_side})())
                if len(state.trade_window) > 500:
                    state.trade_window = state.trade_window[-500:]
            await asyncio.sleep(0.1)

    def _handle_depth(self, data: dict) -> None:
        symbol = data.get("s")
        if symbol not in self.symbol_states:
            return
        state = self.symbol_states[symbol]
        bids = {float(p): float(q) for p, q in data.get("b", [])[: settings.book_levels] if float(q) > 0}
        asks = {float(p): float(q) for p, q in data.get("a", [])[: settings.book_levels] if float(q) > 0}
        if not bids or not asks:
            return
        state.bids = bids
        state.asks = asks
        state.updated_monotonic = time.monotonic()
        best_bid = max(bids)
        best_ask = min(asks)
        mid = (best_bid + best_ask) / 2.0
        state.last_mid = mid
        state.price_history.append(mid)
        if len(state.price_history) > 500:
            state.price_history = state.price_history[-500:]

    def _handle_trade(self, data: dict) -> None:
        symbol = data.get("s")
        if symbol not in self.symbol_states:
            return
        state = self.symbol_states[symbol]
        price = float(data.get("p", 0.0))
        qty = float(data.get("q", 0.0))
        m = bool(data.get("m", False))
        side = "sell_taker" if m else "buy_taker"
        state.trade_window.append(type("TP", (), {"ts": iso_ts(), "price": price, "qty": qty, "side": side})())
        if len(state.trade_window) > 500:
            state.trade_window = state.trade_window[-500:]

    def _event(self, level: str, component: str, event_type: str, symbol: str, details: str) -> None:
        ts = iso_ts()
        event = SystemEvent(ts, level, component, event_type, symbol, details)
        insert_rows(
            settings.table("system_events"),
            [[event.ts, event.level, event.component, event.event_type, event.symbol, event.details]],
            ["ts", "level", "component", "event_type", "symbol", "details"],
        )
        print(f"[{ts}] {level:<5} {component:<9} {event_type:<24} {symbol} {details}")

    async def _feature_loop(self) -> None:
        await asyncio.sleep(2)
        while self.running:
            cycle_start = time.monotonic()
            ts = iso_ts()

            orderbook_rows, agent_rows, signal_rows = [], [], []
            event_rows, order_rows, fill_rows, position_rows, trade_rows = [], [], [], [], []

            portfolio = self.risk.build_portfolio_snapshot(
                self.execution.positions,
                len(self.execution.pending_orders),
                self.execution.balance_usdt,
                self.execution.realized_pnl_usdt,
            )
            portfolio.ts = ts

            live_features = 0
            active_signals = 0

            for symbol, state in self.symbol_states.items():
                feat = compute_feature_snapshot(symbol, state, ts, time.monotonic())
                if not feat:
                    continue
                live_features += 1

                orderbook_rows.append([
                    feat.ts, feat.symbol, feat.mid, feat.best_bid, feat.best_ask, feat.bid_qty_top, feat.ask_qty_top,
                    feat.spread_bps, feat.imbalance, feat.wall_bid_share, feat.wall_ask_share, feat.depth_slope,
                    feat.refill_ratio, feat.depletion_ratio, feat.trade_imbalance, feat.signed_volume, feat.toxicity,
                    feat.sweep_score, feat.atr, feat.realized_vol, feat.hurst, feat.regime, feat.aggress_buy_qty,
                    feat.aggress_sell_qty, feat.stale,
                ])

                votes = generate_votes(feat)
                for vote in votes:
                    agent_rows.append([vote.ts, vote.symbol, vote.agent, vote.vote, vote.score, vote.reason, vote.diagnostics_json])

                signal = self.resolver.resolve(feat, votes)
                signal_rows.append([
                    signal.ts, signal.signal_id, signal.symbol, signal.action, signal.confidence, signal.long_score,
                    signal.short_score, signal.reason, signal.regime, signal.hurst, signal.mid, signal.risk_state,
                ])

                risk_decision = self.risk.evaluate_entry(signal, feat, portfolio, self.execution.positions)
                self.pending_risk[signal.signal_id] = risk_decision
                if signal.action != "flat":
                    active_signals += 1

                pre_entry = self.execution.pre_entry_check(signal, feat)
                order_rows.extend(pre_entry.update.order_rows)
                fill_rows.extend(pre_entry.update.fill_rows)
                position_rows.extend(pre_entry.update.position_rows)
                trade_rows.extend(pre_entry.update.trade_rows)
                for ev in pre_entry.update.events:
                    event_rows.append([ev.ts, ev.level, ev.component, ev.event_type, ev.symbol, ev.details])
                    if ev.event_type == "position_closed":
                        try:
                            pnl = float(ev.details.split("pnl=")[-1])
                            self.risk.record_closed_trade(pnl)
                        except Exception:
                            pass

                if risk_decision.allowed and pre_entry.allow_submit:
                    order, event = self.execution.submit_order(signal, feat, risk_decision)
                    order_rows.append([
                        ts, order.order_id, order.signal_id, order.symbol, order.side, order.intent, order.limit_price,
                        order.qty, order.leverage, order.notional_usdt, order.state, order.filled_qty,
                        order.avg_fill_price, order.queue_ahead_qty, order.ttl_seconds, order.reason,
                    ])
                    event_rows.append([event.ts, event.level, event.component, event.event_type, event.symbol, event.details])

                exec_update = self.execution.process_symbol(feat, self.pending_risk)
                order_rows.extend(exec_update.order_rows)
                fill_rows.extend(exec_update.fill_rows)
                position_rows.extend(exec_update.position_rows)
                trade_rows.extend(exec_update.trade_rows)
                for ev in exec_update.events:
                    event_rows.append([ev.ts, ev.level, ev.component, ev.event_type, ev.symbol, ev.details])
                    if ev.event_type == "position_closed":
                        try:
                            pnl = float(ev.details.split("pnl=")[-1])
                            self.risk.record_closed_trade(pnl)
                        except Exception:
                            pass

            if len(self.pending_risk) > 5000:
                recent_items = list(self.pending_risk.items())[-2000:]
                self.pending_risk = dict(recent_items)

            insert_rows(
                settings.table("orderbook_features"),
                orderbook_rows,
                [
                    "ts", "symbol", "mid", "best_bid", "best_ask", "bid_qty_top", "ask_qty_top", "spread_bps",
                    "imbalance", "wall_bid_share", "wall_ask_share", "depth_slope", "refill_ratio", "depletion_ratio",
                    "trade_imbalance", "signed_volume", "toxicity", "sweep_score", "atr", "realized_vol", "hurst",
                    "regime", "aggress_buy_qty", "aggress_sell_qty", "stale"
                ],
            )
            insert_rows(settings.table("agent_votes"), agent_rows, ["ts", "symbol", "agent", "vote", "score", "reason", "diagnostics_json"])
            insert_rows(
                settings.table("resolver_signals"),
                signal_rows,
                ["ts", "signal_id", "symbol", "action", "confidence", "long_score", "short_score", "reason", "regime", "hurst", "mid", "risk_state"],
            )
            insert_rows(
                settings.table("paper_orders"),
                order_rows,
                ["ts", "order_id", "signal_id", "symbol", "side", "intent", "limit_price", "qty", "leverage", "notional_usdt", "state", "filled_qty", "avg_fill_price", "queue_ahead_qty", "ttl_seconds", "reason"],
            )
            insert_rows(
                settings.table("paper_fills"),
                fill_rows,
                ["ts", "order_id", "signal_id", "symbol", "side", "fill_price", "fill_qty", "fill_type", "slippage_bps"],
            )
            insert_rows(
                settings.table("paper_positions"),
                position_rows,
                ["ts", "position_id", "symbol", "side", "qty", "leverage", "entry_price", "mark_price", "notional_usdt", "unrealized_pnl_usdt", "stop_price", "take_profit_price", "trailing_stop_price", "regime", "status", "entry_reason"],
            )
            insert_rows(
                settings.table("paper_trades"),
                trade_rows,
                ["ts", "trade_id", "position_id", "symbol", "side", "entry_price", "exit_price", "qty", "leverage", "gross_pnl_usdt", "net_pnl_usdt", "exit_reason", "hold_seconds"],
            )

            portfolio = self.risk.build_portfolio_snapshot(
                self.execution.positions,
                len(self.execution.pending_orders),
                self.execution.balance_usdt,
                self.execution.realized_pnl_usdt,
            )
            portfolio.ts = ts
            insert_rows(
                settings.table("portfolio_metrics"),
                [[portfolio.ts, portfolio.balance_usdt, portfolio.realized_pnl_usdt, portfolio.total_leverage, portfolio.open_positions, portfolio.drawdown_pct, portfolio.win_rate, portfolio.avg_win_usdt, portfolio.avg_loss_usdt, portfolio.pending_orders]],
                ["ts", "balance_usdt", "realized_pnl_usdt", "total_leverage", "open_positions", "drawdown_pct", "win_rate", "avg_win_usdt", "avg_loss_usdt", "pending_orders"],
            )
            insert_rows(settings.table("system_events"), event_rows, ["ts", "level", "component", "event_type", "symbol", "details"])

            print(
                f"[{ts}] tracking={len(settings.symbols)} live_features={live_features} "
                f"signals={active_signals} pending={len(self.execution.pending_orders)} "
                f"open_pos={len(self.execution.positions)} pnl={self.execution.realized_pnl_usdt:.2f} "
                f"lev={portfolio.total_leverage:.2f}x dd={portfolio.drawdown_pct * 100:.1f}%"
            )

            elapsed = time.monotonic() - cycle_start
            await asyncio.sleep(max(0.05, settings.feature_interval_seconds - elapsed))


async def main() -> None:
    engine = TradingEngine()
    await engine.run()


if __name__ == "__main__":
    asyncio.run(main())
