from __future__ import annotations

import json
from typing import List

from .schemas import AgentVote, FeatureSnapshot


def _vote(ts: str, symbol: str, agent: str, vote: str, score: float, reason: str, diagnostics: dict | None = None) -> AgentVote:
    return AgentVote(
        ts=ts,
        symbol=symbol,
        agent=agent,
        vote=vote,
        score=max(0.0, min(score, 1.0)),
        reason=reason,
        diagnostics_json=json.dumps(diagnostics or {}, ensure_ascii=False),
    )


def depth_agent(feat: FeatureSnapshot) -> AgentVote:
    edge = feat.imbalance - 0.5
    if edge > 0.08:
        return _vote(feat.ts, feat.symbol, "depth", "long", min(abs(edge) * 6.0, 1.0), "top_depth_bid_dominance", {"imbalance": feat.imbalance})
    if edge < -0.08:
        return _vote(feat.ts, feat.symbol, "depth", "short", min(abs(edge) * 6.0, 1.0), "top_depth_ask_dominance", {"imbalance": feat.imbalance})
    return _vote(feat.ts, feat.symbol, "depth", "flat", 0.15, "balanced_depth", {"imbalance": feat.imbalance})


def density_agent(feat: FeatureSnapshot) -> AgentVote:
    if feat.wall_bid_share > 0.36 and feat.wall_bid_share > feat.wall_ask_share + 0.08:
        return _vote(feat.ts, feat.symbol, "density", "long", min(feat.wall_bid_share * 1.7, 1.0), "bid_wall_support", {"wall_bid_share": feat.wall_bid_share})
    if feat.wall_ask_share > 0.36 and feat.wall_ask_share > feat.wall_bid_share + 0.08:
        return _vote(feat.ts, feat.symbol, "density", "short", min(feat.wall_ask_share * 1.7, 1.0), "ask_wall_pressure", {"wall_ask_share": feat.wall_ask_share})
    return _vote(feat.ts, feat.symbol, "density", "flat", 0.10, "no_dominant_wall")


def spread_agent(feat: FeatureSnapshot) -> AgentVote:
    if feat.spread_bps > 8:
        return _vote(feat.ts, feat.symbol, "spread", "block", min(feat.spread_bps / 15.0, 1.0), "spread_too_wide", {"spread_bps": feat.spread_bps})
    if feat.spread_bps < 2.5 and feat.trade_imbalance > 0.10:
        return _vote(feat.ts, feat.symbol, "spread", "long", 0.45, "tight_spread_flow_support")
    if feat.spread_bps < 2.5 and feat.trade_imbalance < -0.10:
        return _vote(feat.ts, feat.symbol, "spread", "short", 0.45, "tight_spread_flow_pressure")
    return _vote(feat.ts, feat.symbol, "spread", "flat", 0.10, "neutral_spread")


def volume_agent(feat: FeatureSnapshot) -> AgentVote:
    if feat.trade_imbalance > 0.18 and feat.signed_volume > 0:
        return _vote(feat.ts, feat.symbol, "volume", "long", min(abs(feat.trade_imbalance) * 2.8, 1.0), "aggressive_buying", {"buy_qty": feat.aggress_buy_qty})
    if feat.trade_imbalance < -0.18 and feat.signed_volume < 0:
        return _vote(feat.ts, feat.symbol, "volume", "short", min(abs(feat.trade_imbalance) * 2.8, 1.0), "aggressive_selling", {"sell_qty": feat.aggress_sell_qty})
    return _vote(feat.ts, feat.symbol, "volume", "flat", 0.10, "flow_balanced")


def microstructure_agent(feat: FeatureSnapshot) -> AgentVote:
    long_case = feat.trade_imbalance > 0.15 and feat.imbalance > 0.53 and feat.sweep_score < 0.45
    short_case = feat.trade_imbalance < -0.15 and feat.imbalance < 0.47 and feat.sweep_score < 0.45
    if long_case:
        return _vote(feat.ts, feat.symbol, "microstructure", "long", 0.62, "flow_and_book_align")
    if short_case:
        return _vote(feat.ts, feat.symbol, "microstructure", "short", 0.62, "flow_and_book_align")
    if feat.sweep_score >= 0.45:
        return _vote(feat.ts, feat.symbol, "microstructure", "block", min(feat.sweep_score, 1.0), "sweep_detected")
    return _vote(feat.ts, feat.symbol, "microstructure", "flat", 0.10, "no_alignment")


def toxicity_guard(feat: FeatureSnapshot) -> AgentVote:
    if feat.toxicity >= 0.70:
        return _vote(feat.ts, feat.symbol, "toxicity_guard", "block", feat.toxicity, "toxic_order_flow", {"toxicity": feat.toxicity})
    return _vote(feat.ts, feat.symbol, "toxicity_guard", "flat", 0.05, "toxicity_ok")


def regime_guard(feat: FeatureSnapshot) -> AgentVote:
    if feat.regime == "MEAN_REVERT" and abs(feat.trade_imbalance) > 0.30 and feat.sweep_score > 0.25:
        return _vote(feat.ts, feat.symbol, "regime_guard", "block", 0.65, "trend_shock_in_mean_revert")
    if feat.regime == "TRENDING" and feat.spread_bps > 6:
        return _vote(feat.ts, feat.symbol, "regime_guard", "block", 0.55, "spread_not_suitable_for_trend_entry")
    return _vote(feat.ts, feat.symbol, "regime_guard", "flat", 0.05, "regime_ok")


def generate_votes(feat: FeatureSnapshot) -> List[AgentVote]:
    return [
        depth_agent(feat),
        density_agent(feat),
        spread_agent(feat),
        volume_agent(feat),
        microstructure_agent(feat),
        toxicity_guard(feat),
        regime_guard(feat),
    ]
