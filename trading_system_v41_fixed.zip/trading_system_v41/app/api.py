from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

from .config import settings
from .storage import get_client


def _root_dir() -> Path:
    return Path(__file__).resolve().parents[1]


def _dashboard_path() -> Path:
    p = Path(settings.dashboard_html)
    if p.is_absolute():
        return p
    return (_root_dir() / p).resolve()


def get_ch():
    return get_client()


def _scalar(ch, sql: str, parameters: dict | None = None, default: Any = 0) -> Any:
    try:
        rows = ch.query(sql, parameters=parameters).result_rows
        if not rows:
            return default
        row = rows[0]
        if row is None:
            return default
        if isinstance(row, (list, tuple)):
            return row[0] if row else default
        return row
    except Exception:
        return default


app = FastAPI(title="Trading System V4.1 Dashboard API", version="1.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root() -> FileResponse:
    return FileResponse(str(_dashboard_path()))


@app.get("/api/health")
def health() -> Dict[str, Any]:
    ch = get_ch()
    try:
        ch.query("SELECT 1")
        signals = _scalar(ch, f"SELECT count() FROM {settings.table('resolver_signals')} WHERE ts >= now() - INTERVAL 1 HOUR", default=0)
        orders = _scalar(ch, f"SELECT count() FROM {settings.table('paper_orders')} WHERE ts >= now() - INTERVAL 1 HOUR", default=0)
        fills = _scalar(ch, f"SELECT count() FROM {settings.table('paper_fills')} WHERE ts >= now() - INTERVAL 1 HOUR", default=0)
        trades = _scalar(ch, f"SELECT count() FROM {settings.table('paper_trades')} WHERE ts >= now() - INTERVAL 1 HOUR", default=0)
        notes = _scalar(ch, f"SELECT count() FROM {settings.table('oracle_notes')} WHERE ts >= now() - INTERVAL 1 HOUR", default=0)
        return {
            "status": "healthy",
            "clickhouse": "connected",
            "signals_1h": int(signals or 0),
            "orders_1h": int(orders or 0),
            "fills_1h": int(fills or 0),
            "trades_1h": int(trades or 0),
            "oracle_notes_1h": int(notes or 0),
        }
    except Exception as exc:
        return {"status": "error", "error": str(exc)}


@app.get("/api/portfolio")
def portfolio() -> Dict[str, Any]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, balance_usdt, realized_pnl_usdt, total_leverage, open_positions,
                   drawdown_pct, win_rate, avg_win_usdt, avg_loss_usdt, pending_orders
            FROM {settings.table('portfolio_metrics')}
            ORDER BY ts DESC
            LIMIT 1
            """
        ).result_rows
        if not rows:
            return {
                "ts": None,
                "balance_usdt": float(settings.paper_deposit_usdt),
                "realized_pnl_usdt": 0.0,
                "total_leverage": 0.0,
                "open_positions": 0,
                "drawdown_pct": 0.0,
                "win_rate": 0.5,
                "avg_win_usdt": 0.0,
                "avg_loss_usdt": 0.0,
                "pending_orders": 0,
            }
        row = rows[0]
        return {
            "ts": str(row[0]),
            "balance_usdt": float(row[1]),
            "realized_pnl_usdt": float(row[2]),
            "total_leverage": float(row[3]),
            "open_positions": int(row[4]),
            "drawdown_pct": float(row[5]),
            "win_rate": float(row[6]),
            "avg_win_usdt": float(row[7]),
            "avg_loss_usdt": float(row[8]),
            "pending_orders": int(row[9]),
        }
    except Exception as exc:
        return {"error": str(exc)}


@app.get("/api/recent-signals")
def recent_signals(limit: int = Query(default=25, le=100)) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, symbol, action, confidence, reason, regime, long_score, short_score
            FROM {settings.table('resolver_signals')}
            ORDER BY ts DESC
            LIMIT %(limit)s
            """,
            parameters={"limit": limit},
        ).result_rows
        return [
            {
                "ts": str(r[0]),
                "symbol": r[1],
                "action": r[2],
                "confidence": float(r[3]),
                "reason": r[4],
                "regime": r[5],
                "long_score": float(r[6]),
                "short_score": float(r[7]),
            }
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/agent-votes")
def agent_votes(
    symbol: str = "BTCUSDT",
    limit: int = Query(default=50, le=200),
) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, agent, vote, score, reason
            FROM {settings.table('agent_votes')}
            WHERE symbol = %(symbol)s
            ORDER BY ts DESC
            LIMIT %(limit)s
            """,
            parameters={"symbol": symbol.upper(), "limit": limit},
        ).result_rows
        return [
            {"ts": str(r[0]), "agent": r[1], "vote": r[2], "score": float(r[3]), "reason": r[4]}
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/open-positions")
def open_positions() -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT position_id, symbol, side, qty, leverage, entry_price, mark_price,
                   notional_usdt, unrealized_pnl_usdt, stop_price, take_profit_price,
                   trailing_stop_price, regime, status, entry_reason, ts
            FROM {settings.table('paper_positions')}
            WHERE (position_id, ts) IN (
                SELECT position_id, max(ts)
                FROM {settings.table('paper_positions')}
                GROUP BY position_id
            )
            AND status = 'OPEN'
            ORDER BY ts DESC
            LIMIT 50
            """
        ).result_rows
        return [
            {
                "position_id": r[0], "symbol": r[1], "side": r[2],
                "qty": float(r[3]), "leverage": float(r[4]),
                "entry_price": float(r[5]), "mark_price": float(r[6]),
                "notional_usdt": float(r[7]), "unrealized_pnl_usdt": float(r[8]),
                "stop_price": float(r[9]), "take_profit_price": float(r[10]),
                "trailing_stop_price": float(r[11]), "regime": r[12],
                "status": r[13], "entry_reason": r[14], "ts": str(r[15]),
            }
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/pending-orders")
def pending_orders() -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT order_id, signal_id, symbol, side, intent, limit_price, qty,
                   leverage, state, filled_qty, avg_fill_price, queue_ahead_qty,
                   ttl_seconds, reason, ts
            FROM {settings.table('paper_orders')}
            WHERE (order_id, ts) IN (
                SELECT order_id, max(ts)
                FROM {settings.table('paper_orders')}
                GROUP BY order_id
            )
            AND state IN ('NEW', 'PARTIAL')
            ORDER BY ts DESC
            LIMIT 50
            """
        ).result_rows
        return [
            {
                "order_id": r[0], "signal_id": r[1], "symbol": r[2], "side": r[3],
                "intent": r[4], "limit_price": float(r[5]), "qty": float(r[6]),
                "leverage": float(r[7]), "state": r[8], "filled_qty": float(r[9]),
                "avg_fill_price": float(r[10]), "queue_ahead_qty": float(r[11]),
                "ttl_seconds": float(r[12]), "reason": r[13], "ts": str(r[14]),
            }
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/recent-trades")
def recent_trades(limit: int = Query(default=25, le=100)) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, trade_id, position_id, symbol, side, entry_price, exit_price,
                   qty, leverage, gross_pnl_usdt, net_pnl_usdt, exit_reason, hold_seconds
            FROM {settings.table('paper_trades')}
            ORDER BY ts DESC
            LIMIT %(limit)s
            """,
            parameters={"limit": limit},
        ).result_rows
        return [
            {
                "ts": str(r[0]), "trade_id": r[1], "position_id": r[2],
                "symbol": r[3], "side": r[4],
                "entry_price": float(r[5]), "exit_price": float(r[6]),
                "qty": float(r[7]), "leverage": float(r[8]),
                "gross_pnl_usdt": float(r[9]), "net_pnl_usdt": float(r[10]),
                "exit_reason": r[11], "hold_seconds": float(r[12]),
            }
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/top-symbol-pnl")
def top_symbol_pnl(hours: int = 24) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT symbol, side, count() AS trades, sum(net_pnl_usdt) AS net_pnl
            FROM {settings.table('paper_trades')}
            WHERE ts >= now() - INTERVAL %(hours)s HOUR
            GROUP BY symbol, side
            ORDER BY net_pnl DESC
            LIMIT 16
            """,
            parameters={"hours": hours},
        ).result_rows
        return [
            {"symbol": r[0], "side": r[1], "trades": int(r[2]), "net_pnl": float(r[3])}
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/oracle/latest")
def oracle_latest(limit: int = Query(default=10, le=50)) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, symbol, note_type, signal_id, recommendation, confidence,
                   analysis, model, tokens_used, ollama_latency_ms
            FROM {settings.table('oracle_notes')}
            ORDER BY ts DESC
            LIMIT %(limit)s
            """,
            parameters={"limit": limit},
        ).result_rows
        return [
            {
                "ts": str(r[0]), "symbol": r[1], "note_type": r[2],
                "signal_id": r[3], "recommendation": r[4],
                "confidence": float(r[5]), "analysis": r[6],
                "model": r[7], "tokens_used": int(r[8]), "ollama_latency_ms": int(r[9]),
            }
            for r in rows
        ]
    except Exception:
        return []


@app.get("/api/equity-curve")
def equity_curve(limit: int = Query(default=500, le=2000)) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, equity
            FROM (
                SELECT ts, balance_usdt + realized_pnl_usdt AS equity
                FROM {settings.table('portfolio_metrics')}
                ORDER BY ts DESC
                LIMIT %(limit)s
            )
            ORDER BY ts ASC
            """,
            parameters={"limit": limit},
        ).result_rows
        return [{"ts": str(r[0]), "equity": float(r[1])} for r in rows]
    except Exception:
        return []


@app.get("/api/execution-metrics")
def execution_metrics() -> Dict[str, Any]:
    ch = get_ch()
    try:
        fill_count = _scalar(ch, f"SELECT count() FROM {settings.table('paper_fills')}", default=0)
        trade_count = _scalar(ch, f"SELECT count() FROM {settings.table('paper_trades')}", default=0)
        avg_fill_slippage = _scalar(ch, f"SELECT avg(slippage_bps) FROM {settings.table('paper_fills')}", default=0.0) or 0.0
        avg_hold = _scalar(ch, f"SELECT avg(hold_seconds) FROM {settings.table('paper_trades')}", default=0.0) or 0.0
        avg_trade = _scalar(ch, f"SELECT avg(net_pnl_usdt) FROM {settings.table('paper_trades')}", default=0.0) or 0.0
        return {
            "fill_count": int(fill_count or 0),
            "trade_count": int(trade_count or 0),
            "avg_fill_slippage_bps": float(avg_fill_slippage),
            "avg_hold_seconds": float(avg_hold),
            "avg_trade_net_usdt": float(avg_trade),
        }
    except Exception as exc:
        return {
            "error": str(exc), "fill_count": 0, "trade_count": 0,
            "avg_fill_slippage_bps": 0.0, "avg_hold_seconds": 0.0, "avg_trade_net_usdt": 0.0,
        }


@app.get("/api/system-events")
def system_events(limit: int = Query(default=50, le=200)) -> List[Dict[str, Any]]:
    ch = get_ch()
    try:
        rows = ch.query(
            f"""
            SELECT ts, level, component, event_type, symbol, details
            FROM {settings.table('system_events')}
            ORDER BY ts DESC
            LIMIT %(limit)s
            """,
            parameters={"limit": limit},
        ).result_rows
        return [
            {"ts": str(r[0]), "level": r[1], "component": r[2],
             "event_type": r[3], "symbol": r[4], "details": r[5]}
            for r in rows
        ]
    except Exception:
        return []
