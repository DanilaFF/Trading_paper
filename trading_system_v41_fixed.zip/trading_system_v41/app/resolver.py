from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, List

from .config import settings
from .schemas import AgentVote, FeatureSnapshot, ResolverSignal


REGIME_WEIGHTS: dict[str, dict[str, float]] = {
    "TRENDING": {
        "depth": 0.85,
        "density": 0.80,
        "spread": 0.65,
        "volume": 1.10,
        "microstructure": 1.20,
        "toxicity_guard": 1.0,
        "regime_guard": 1.0,
    },
    "MEAN_REVERT": {
        "depth": 1.15,
        "density": 1.15,
        "spread": 0.85,
        "volume": 0.75,
        "microstructure": 0.90,
        "toxicity_guard": 1.0,
        "regime_guard": 1.0,
    },
    "NEUTRAL": {
        "depth": 1.0,
        "density": 1.0,
        "spread": 0.8,
        "volume": 0.95,
        "microstructure": 1.0,
        "toxicity_guard": 1.0,
        "regime_guard": 1.0,
    },
}

LONG_THRESHOLDS = {"TRENDING": 1.62, "MEAN_REVERT": 1.68, "NEUTRAL": 1.65}
SHORT_THRESHOLDS = {"TRENDING": 1.95, "MEAN_REVERT": 2.10, "NEUTRAL": 1.95}


@dataclass(slots=True)
class SymbolResolverState:
    last_action: str = "flat"
    last_decision_mono: float = 0.0


@dataclass(slots=True)
class Resolver:
    cooldown_seconds: float = 10.0
    state_by_symbol: Dict[str, SymbolResolverState] = field(default_factory=dict)

    def resolve(self, feat: FeatureSnapshot, votes: List[AgentVote]) -> ResolverSignal:
        weights = REGIME_WEIGHTS.get(feat.regime, REGIME_WEIGHTS["NEUTRAL"])
        now_mono = time.monotonic()
        sym_state = self.state_by_symbol.setdefault(feat.symbol, SymbolResolverState())

        blockers = [v for v in votes if v.vote == "block" and v.score >= 0.65]
        if feat.stale:
            blockers.append(AgentVote(ts=feat.ts, symbol=feat.symbol, agent="stale_guard", vote="block", score=1.0, reason="stale_market_data"))

        long_score = sum(v.score * weights.get(v.agent, 1.0) for v in votes if v.vote == "long")
        short_score = sum(v.score * weights.get(v.agent, 1.0) for v in votes if v.vote == "short")

        action = "flat"
        confidence = 0.0
        reason = "no_consensus"

        if blockers:
            reason = "blocked_" + blockers[0].reason
        else:
            long_threshold = LONG_THRESHOLDS.get(feat.regime, 1.65)
            short_threshold = SHORT_THRESHOLDS.get(feat.regime, 1.95)
            short_dom_factor = 1.12
            long_dom_factor = 1.05

            if long_score >= long_threshold and long_score > short_score * long_dom_factor:
                action = "long"
                confidence = min(long_score / 3.4, 0.95)
                reason = f"long_consensus_{feat.regime.lower()}"
            elif short_score >= short_threshold and short_score > long_score * short_dom_factor:
                action = "short"
                confidence = min(short_score / 3.8, 0.95)
                reason = f"short_consensus_{feat.regime.lower()}"

        if action != "flat" and sym_state.last_action not in ("flat", action) and (now_mono - sym_state.last_decision_mono) < self.cooldown_seconds:
            action = "flat"
            confidence = 0.0
            reason = "anti_flip_cooldown"

        min_conf = settings.min_resolver_confidence
        if action == "short":
            min_conf *= settings.short_confidence_multiplier

        if confidence < min_conf:
            action = "flat"
            if reason.startswith(("long_", "short_")):
                reason = "confidence_below_threshold"

        if action != "flat":
            sym_state.last_action = action
            sym_state.last_decision_mono = now_mono
        elif (now_mono - sym_state.last_decision_mono) >= self.cooldown_seconds:
            sym_state.last_action = "flat"

        return ResolverSignal(
            ts=feat.ts,
            signal_id=str(uuid.uuid4()),
            symbol=feat.symbol,
            action=action,
            confidence=confidence,
            long_score=long_score,
            short_score=short_score,
            reason=reason,
            regime=feat.regime,
            hurst=feat.hurst,
            mid=feat.mid,
            risk_state="ok" if not blockers else "blocked",
        )
