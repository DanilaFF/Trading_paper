from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from .config import settings
from .schemas import FeatureSnapshot, PortfolioState, Position, ResolverSignal


def kelly_fractional(win_rate: float, avg_win: float, avg_loss: float, fraction: float) -> float:
    if avg_loss <= 0 or avg_win <= 0 or not (0 < win_rate < 1):
        return 0.02
    b = avg_win / avg_loss
    q = 1.0 - win_rate
    raw = (b * win_rate - q) / b if b > 0 else 0.0
    raw = max(0.0, min(raw, 0.50))
    return raw * fraction


@dataclass(slots=True)
class RiskDecision:
    allowed: bool
    reason: str
    leverage: float = 0.0
    qty: float = 0.0
    notional_usdt: float = 0.0
    stop_price: float = 0.0
    tp1_price: float = 0.0
    tp2_price: float = 0.0


@dataclass(slots=True)
class RiskManager:
    equity_high_watermark: float = settings.paper_deposit_usdt
    closed_trades: list[float] = field(default_factory=list)

    def _drawdown_pct(self, equity: float) -> float:
        self.equity_high_watermark = max(self.equity_high_watermark, equity)
        dd = 1.0 - (equity / self.equity_high_watermark if self.equity_high_watermark > 0 else 1.0)
        return max(0.0, dd)

    def build_portfolio_snapshot(self, positions: Dict[str, Position], pending_orders: int, balance_usdt: float, realized_pnl_usdt: float) -> PortfolioState:
        unreal = sum(p.unrealized_pnl_usdt for p in positions.values())
        equity = balance_usdt + realized_pnl_usdt + unreal
        total_notional = sum(p.notional_usdt for p in positions.values() if p.status == "OPEN")
        total_leverage = total_notional / max(equity, 1.0)

        wins = [p for p in self.closed_trades if p > 0]
        losses = [abs(p) for p in self.closed_trades if p < 0]
        win_rate = len(wins) / len(self.closed_trades) if self.closed_trades else 0.5
        avg_win = sum(wins) / len(wins) if wins else 20.0
        avg_loss = sum(losses) / len(losses) if losses else 15.0

        return PortfolioState(
            ts="",
            balance_usdt=balance_usdt,
            realized_pnl_usdt=realized_pnl_usdt,
            total_leverage=total_leverage,
            open_positions=sum(1 for p in positions.values() if p.status == "OPEN"),
            drawdown_pct=self._drawdown_pct(equity),
            win_rate=win_rate,
            avg_win_usdt=avg_win,
            avg_loss_usdt=avg_loss,
            pending_orders=pending_orders,
        )

    def evaluate_entry(self, signal: ResolverSignal, feat: FeatureSnapshot, portfolio: PortfolioState, open_positions: Dict[str, Position]) -> RiskDecision:
        if signal.action == "flat":
            return RiskDecision(False, "flat_signal")
        if feat.stale:
            return RiskDecision(False, "stale_data")
        if not settings.side_allowed(signal.symbol, signal.action):
            return RiskDecision(False, f"{signal.action}_disabled_for_symbol")
        if portfolio.open_positions >= settings.max_open_positions:
            return RiskDecision(False, "max_open_positions")
        if portfolio.total_leverage >= settings.max_portfolio_leverage:
            return RiskDecision(False, "portfolio_leverage_cap")
        if portfolio.drawdown_pct >= settings.max_drawdown_pct:
            return RiskDecision(False, "drawdown_lock")
        if feat.toxicity >= 0.82:
            return RiskDecision(False, "toxicity_lock")

        same_symbol_open = [p for p in open_positions.values() if p.symbol == signal.symbol and p.status == "OPEN"]
        if len(same_symbol_open) >= settings.max_positions_per_symbol:
            return RiskDecision(False, "symbol_position_cap")

        kelly = kelly_fractional(
            portfolio.win_rate,
            max(portfolio.avg_win_usdt, 1.0),
            max(portfolio.avg_loss_usdt, 1.0),
            settings.kelly_fraction,
        )
        equity = settings.paper_deposit_usdt + portfolio.realized_pnl_usdt
        risk_budget = max(equity * settings.risk_per_trade_pct, 5.0)
        base_notional = equity * min(settings.max_position_size_pct, max(kelly, 0.01))

        regime_mult = 1.0
        if feat.regime == "TRENDING":
            regime_mult = 0.95 if signal.action == "long" else 0.80
        elif feat.regime == "MEAN_REVERT":
            regime_mult = 0.90 if signal.action == "long" else 0.70
        confidence_mult = max(0.65, signal.confidence)
        notional = min(base_notional * regime_mult * confidence_mult, equity * settings.max_position_size_pct)

        atr = max(feat.atr, feat.mid * 0.00125)
        stop_distance = atr * settings.atr_multiplier
        if stop_distance <= 0:
            return RiskDecision(False, "invalid_stop_distance")

        raw_leverage = max(settings.min_leverage, min(settings.max_leverage, notional / max(risk_budget, 1.0)))
        if signal.action == "short":
            raw_leverage *= 0.92
        leverage = max(settings.min_leverage, min(settings.max_leverage, raw_leverage))

        qty = max(notional / max(feat.mid, 1.0), 0.0)
        if qty <= 0:
            return RiskDecision(False, "qty_zero")

        if signal.action == "long":
            stop_price = feat.mid - stop_distance
            tp1_price = feat.mid + stop_distance * settings.tp1_r_multiple
            tp2_price = feat.mid + stop_distance * settings.tp2_r_multiple
        else:
            stop_price = feat.mid + stop_distance
            tp1_price = feat.mid - stop_distance * settings.tp1_r_multiple
            tp2_price = feat.mid - stop_distance * settings.tp2_r_multiple

        return RiskDecision(
            True,
            "ok",
            leverage=leverage,
            qty=qty,
            notional_usdt=notional,
            stop_price=stop_price,
            tp1_price=tp1_price,
            tp2_price=tp2_price,
        )

    def record_closed_trade(self, net_pnl: float) -> None:
        self.closed_trades.append(net_pnl)
        if len(self.closed_trades) > 1000:
            self.closed_trades = self.closed_trades[-1000:]
