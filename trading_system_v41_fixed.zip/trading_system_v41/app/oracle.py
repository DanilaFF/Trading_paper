from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import requests

from .config import settings
from .storage import get_client, init_schema, insert_rows


def iso_ts() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def call_ollama(prompt: str) -> tuple[Optional[str], int, int]:
    payload = {
        "model": settings.ollama_model,
        "messages": [
            {"role": "system", "content": "You are a concise quantitative crypto risk analyst. Advisory only. Return structured output."},
            {"role": "user", "content": prompt},
        ],
        "stream": False,
        "keep_alive": "60s",
    }
    started = time.time()
    try:
        response = requests.post(settings.ollama_url, json=payload, timeout=20)
        latency_ms = int((time.time() - started) * 1000)
        response.raise_for_status()
        result = response.json()
        text = result.get("message", {}).get("content", "")
        tokens = int(result.get("prompt_eval_count", 0)) + int(result.get("eval_count", 0))
        return text, tokens, latency_ms
    except Exception as exc:
        print(f"[WARN] Ollama request failed: {exc}")
        return None, 0, int((time.time() - started) * 1000)


def parse_response(text: str) -> tuple[str, float, str]:
    recommendation = "ALLOW"
    confidence = 0.55
    analysis = text.strip()
    for raw in text.splitlines():
        line = raw.strip()
        upper = line.upper()
        if upper.startswith("RECOMMENDATION:"):
            value = line.split(":", 1)[1].strip().upper()
            if value in {"ALLOW", "CAUTION", "REJECT", "REDUCE", "CLOSE_WATCH"}:
                recommendation = value
        elif upper.startswith("CONFIDENCE:"):
            try:
                confidence = float(line.split(":", 1)[1].strip().split()[0])
            except Exception:
                pass
    confidence = max(0.0, min(confidence, 1.0))
    return recommendation, confidence, analysis[:2000]


def build_prompt(symbol: str, signal: Dict[str, Any], votes: List[Dict[str, Any]], portfolio: Dict[str, Any], feature: Dict[str, Any]) -> str:
    confidence = (signal.get("confidence", 0.0) if signal else 0.0)
    return f"""Analyze this paper-trading setup for {symbol}.

PORTFOLIO
- Balance: ${portfolio.get('balance_usdt', 0):.2f}
- Realized PnL: ${portfolio.get('realized_pnl_usdt', 0):.2f}
- Total Leverage: {portfolio.get('total_leverage', 0):.2f}x
- Open Positions: {portfolio.get('open_positions', 0)}
- Drawdown: {portfolio.get('drawdown_pct', 0) * 100:.2f}%
- Win Rate: {portfolio.get('win_rate', 0) * 100:.1f}%

LATEST SIGNAL
- Action: {signal.get('action', 'flat') if signal else 'flat'}
- Confidence: {confidence:.2f}
- Reason: {signal.get('reason', 'no signal') if signal else 'no signal'}
- Regime: {signal.get('regime', feature.get('regime', 'NEUTRAL')) if signal else feature.get('regime', 'NEUTRAL')}

LATEST FEATURES
- Mid: {feature.get('mid', 0):.4f}
- Spread bps: {feature.get('spread_bps', 0):.2f}
- Imbalance: {feature.get('imbalance', 0):.3f}
- Toxicity: {feature.get('toxicity', 0):.3f}
- Sweep score: {feature.get('sweep_score', 0):.3f}
- ATR: {feature.get('atr', 0):.4f}
- Hurst: {feature.get('hurst', 0):.3f}

LATEST VOTES
{json.dumps(votes[:6], indent=2)}

Task:
Should this setup be allowed, flagged with caution, rejected, or closely watched from a risk perspective?
Be conservative about toxic flow and elevated leverage.

Return exactly:
RECOMMENDATION: ALLOW|CAUTION|REJECT|REDUCE|CLOSE_WATCH
CONFIDENCE: 0.50-0.95
ANALYSIS: 2-4 concise sentences
"""


class OracleAgent:
    def __init__(self) -> None:
        self.client = get_client()

    def latest_signal(self, symbol: str) -> Optional[Dict[str, Any]]:
        rows = self.client.query(
            f"""
            SELECT ts, signal_id, action, confidence, reason, regime
            FROM {settings.table('resolver_signals')}
            WHERE symbol = %(symbol)s
            ORDER BY ts DESC
            LIMIT 1
            """,
            parameters={"symbol": symbol},
        ).result_rows
        if not rows:
            return None
        r = rows[0]
        return {"ts": str(r[0]), "signal_id": r[1], "action": r[2], "confidence": float(r[3]), "reason": r[4], "regime": r[5]}

    def latest_votes(self, symbol: str) -> List[Dict[str, Any]]:
        rows = self.client.query(
            f"""
            SELECT ts, agent, vote, score, reason
            FROM {settings.table('agent_votes')}
            WHERE symbol = %(symbol)s
            ORDER BY ts DESC
            LIMIT 10
            """,
            parameters={"symbol": symbol},
        ).result_rows
        return [{"ts": str(r[0]), "agent": r[1], "vote": r[2], "score": float(r[3]), "reason": r[4]} for r in rows]

    def latest_feature(self, symbol: str) -> Optional[Dict[str, Any]]:
        rows = self.client.query(
            f"""
            SELECT ts, mid, spread_bps, imbalance, toxicity, sweep_score, atr, hurst, regime
            FROM {settings.table('orderbook_features')}
            WHERE symbol = %(symbol)s
            ORDER BY ts DESC
            LIMIT 1
            """,
            parameters={"symbol": symbol},
        ).result_rows
        if not rows:
            return None
        r = rows[0]
        return {
            "ts": str(r[0]),
            "mid": float(r[1]),
            "spread_bps": float(r[2]),
            "imbalance": float(r[3]),
            "toxicity": float(r[4]),
            "sweep_score": float(r[5]),
            "atr": float(r[6]),
            "hurst": float(r[7]),
            "regime": r[8],
        }

    def portfolio_state(self) -> Optional[Dict[str, Any]]:
        rows = self.client.query(
            f"""
            SELECT balance_usdt, realized_pnl_usdt, total_leverage, open_positions, drawdown_pct, win_rate
            FROM {settings.table('portfolio_metrics')}
            ORDER BY ts DESC
            LIMIT 1
            """
        ).result_rows
        if not rows:
            return None
        r = rows[0]
        return {
            "balance_usdt": float(r[0]),
            "realized_pnl_usdt": float(r[1]),
            "total_leverage": float(r[2]),
            "open_positions": int(r[3]),
            "drawdown_pct": float(r[4]),
            "win_rate": float(r[5]),
        }

    async def analyze_symbol(self, symbol: str) -> bool:
        signal = self.latest_signal(symbol)
        feature = self.latest_feature(symbol)
        portfolio = self.portfolio_state()
        votes = self.latest_votes(symbol)
        if not feature or not portfolio:
            print(f"[SKIP] {symbol}: insufficient data")
            return False

        prompt = build_prompt(symbol, signal or {}, votes, portfolio, feature)
        text, tokens, latency_ms = call_ollama(prompt)
        if not text:
            return False

        recommendation, confidence, analysis = parse_response(text)
        signal_id = signal.get("signal_id", "") if signal else ""
        row = [[iso_ts(), symbol, "risk_review", signal_id, recommendation, confidence, analysis, settings.ollama_model, tokens, latency_ms]]
        insert_rows(
            settings.table("oracle_notes"),
            row,
            ["ts", "symbol", "note_type", "signal_id", "recommendation", "confidence", "analysis", "model", "tokens_used", "ollama_latency_ms"],
        )
        print(f"[OK] {symbol} rec={recommendation} conf={confidence:.2f} tokens={tokens} latency={latency_ms}ms")
        return True

    async def run(self) -> None:
        init_schema()
        try:
            base = settings.ollama_url.replace("/api/chat", "")
            version = requests.get(f"{base}/api/version", timeout=5)
            version.raise_for_status()
            print(f"[INFO] Ollama reachable: {version.json()}")
        except Exception as exc:
            print(f"[WARN] Could not verify Ollama version: {exc}")

        cycle = 0
        while True:
            cycle += 1
            ts = iso_ts()
            print(f"[{ts}] Oracle cycle #{cycle}")
            success = 0
            for symbol in settings.symbols[: min(6, len(settings.symbols))]:
                try:
                    if await self.analyze_symbol(symbol):
                        success += 1
                except Exception as exc:
                    print(f"[ERROR] {symbol}: {exc}")
            print(f"[INFO] cycle_complete success={success}")
            await asyncio.sleep(settings.oracle_interval_seconds)


async def main() -> None:
    agent = OracleAgent()
    await agent.run()


if __name__ == "__main__":
    asyncio.run(main())
