#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

if [ -f .env ]; then
  set -a
  source .env
  set +a
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"
LOG_PREFIX="/tmp/${TABLE_SUFFIX:-v41}"
ENABLE_ORACLE="${ENABLE_ORACLE:-true}"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: python3 not found"
  exit 1
fi

if [ ! -d .venv ]; then
  echo "[bootstrap] creating virtualenv..."
  "$PYTHON_BIN" -m venv .venv
fi

source .venv/bin/activate
python -m pip install -q --upgrade pip
python -m pip install -q -r requirements.txt

export PYTHONPATH="$ROOT_DIR${PYTHONPATH:+:$PYTHONPATH}"

if ! command -v curl >/dev/null 2>&1; then
  echo "ERROR: curl is required"
  exit 1
fi

echo "[1/4] Checking ClickHouse..."
python scripts/init_clickhouse.py --check-only

echo "[2/4] Initializing schema..."
python scripts/init_clickhouse.py

echo "[3/4] Starting engine + api..."
nohup python scripts/run_engine.py > "${LOG_PREFIX}_engine.log" 2>&1 &
ENGINE_PID=$!
nohup python scripts/run_api.py > "${LOG_PREFIX}_api.log" 2>&1 &
API_PID=$!

ORACLE_PID=""
if [ "$ENABLE_ORACLE" = "true" ]; then
  if curl -fsS "http://localhost:11434/api/version" >/dev/null 2>&1; then
    echo "[4/4] Starting oracle..."
    nohup python scripts/run_oracle.py > "${LOG_PREFIX}_oracle.log" 2>&1 &
    ORACLE_PID=$!
  else
    echo "[4/4] Ollama is not reachable -> oracle skipped (set ENABLE_ORACLE=false to silence this)"
  fi
else
  echo "[4/4] Oracle disabled by ENABLE_ORACLE=false"
fi

sleep 2

echo ""
echo "Trading System V4.1 booted"
echo "  Engine PID:  $ENGINE_PID   log: tail -f ${LOG_PREFIX}_engine.log"
echo "  API PID:     $API_PID      log: tail -f ${LOG_PREFIX}_api.log"
if [ -n "$ORACLE_PID" ]; then
  echo "  Oracle PID:  $ORACLE_PID   log: tail -f ${LOG_PREFIX}_oracle.log"
fi
echo "  Dashboard:   http://127.0.0.1:8000"
echo ""
echo "Quick checks:"
echo "  curl http://127.0.0.1:8000/api/health | python3 -m json.tool"
echo "  curl http://127.0.0.1:8000/api/recent-trades | python3 -m json.tool"
