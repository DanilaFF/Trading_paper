# Bugfix report — Trading System V4.1

## Что было проверено
- синтаксис всех `app/*.py` и `scripts/*.py`
- import smoke check всех модулей
- жизненный цикл позиции: entry -> TP1 -> TP2
- synthetic demo loop без ClickHouse/Ollama через monkeypatch

## Найдено и исправлено
1. `scripts/smoke_test.py` не запускался как обещано в README — не видел пакет `app`.
2. `launcher_v4.sh` был жестко завязан на Ollama и не давал нормально поднять систему без oracle.
3. Не было простого demo-режима для проверки, что стратегия реально генерирует сделки.
4. В synthetic market почти не возникало качественных сигналов, поэтому стратегия могла "работать", но не торговать.
5. В `engine.py` был дублирующийся вызов `generate_votes(feat)`.
6. В `api.py` equity curve бралась как первые N точек, а не последние N точек.
7. В `resolver.py` anti-flip cooldown ослаблялся тем, что состояние символа каждый цикл перезаписывалось в `flat`.
8. `pending_risk` рос без ограничения.

## Что добавлено
- `launcher_v41.sh`
- `launcher_demo.sh`
- `scripts/smoke_test.py`
- `ENABLE_ORACLE=true/false` в конфиге
- обновленные README и START_HERE

## Как запускать
### Быстрый demo
```bash
bash launcher_demo.sh
```

### Полный режим
```bash
bash launcher_v41.sh
```

### Локальная проверка логики
```bash
python scripts/smoke_test.py
```
