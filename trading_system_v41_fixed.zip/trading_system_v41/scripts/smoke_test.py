from __future__ import annotations

import os
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

os.environ.setdefault("MARKET_MODE", "synthetic")

from app.execution import PaperExecution
from app.schemas import FeatureSnapshot, ResolverSignal
from app.risk import RiskDecision
from app.features import compute_feature_snapshot
from app.agents import generate_votes
from app.resolver import Resolver
from app.schemas import SymbolState, TradePrint


def assert_true(cond: bool, msg: str) -> None:
    if not cond:
        raise AssertionError(msg)


def make_feat() -> FeatureSnapshot:
    return FeatureSnapshot(
        ts="2026-01-01T00:00:00.000Z",
        symbol="BTCUSDT",
        mid=100.0,
        best_bid=99.95,
        best_ask=100.05,
        bid_qty_top=1300.0,
        ask_qty_top=900.0,
        spread_bps=1.0,
        imbalance=0.59,
        wall_bid_share=0.46,
        wall_ask_share=0.18,
        depth_slope=0.0,
        refill_ratio=0.1,
        depletion_ratio=-0.1,
        trade_imbalance=0.24,
        signed_volume=220.0,
        toxicity=0.18,
        sweep_score=0.12,
        atr=0.8,
        realized_vol=0.03,
        hurst=0.45,
        regime="NEUTRAL",
        aggress_buy_qty=220.0,
        aggress_sell_qty=80.0,
        stale=0,
    )


def test_execution_lifecycle() -> None:
    exe = PaperExecution()
    feat = make_feat()
    sig = ResolverSignal(
        ts=feat.ts,
        signal_id="sig-1",
        symbol=feat.symbol,
        action="long",
        confidence=0.9,
        long_score=2.2,
        short_score=0.2,
        reason="test_long",
        regime=feat.regime,
        hurst=feat.hurst,
        mid=feat.mid,
    )
    risk = RiskDecision(True, "ok", leverage=2.0, qty=1.0, notional_usdt=100.0, stop_price=98.4, tp1_price=101.2, tp2_price=102.0)

    pre = exe.pre_entry_check(sig, feat)
    assert_true(pre.allow_submit, "pre-entry should allow initial order")
    order, _ = exe.submit_order(sig, feat, risk)
    order.created_monotonic -= 1.0
    exe.process_symbol(feat, {sig.signal_id: risk})
    assert_true(len(exe.positions) == 1, "order should open one position")

    pre2 = exe.pre_entry_check(sig, feat)
    assert_true(not pre2.allow_submit, "dedup/cooldown should block immediate same-symbol re-entry")

    feat_tp1 = FeatureSnapshot(**{**asdict(feat), "ts": "2026-01-01T00:00:10.000Z", "mid": 101.3, "best_bid": 101.25, "best_ask": 101.35})
    upd1 = exe.process_symbol(feat_tp1, {})
    assert_true(any(row[11] == "take_profit_1" for row in upd1.trade_rows), "TP1 partial close must trigger")

    feat_tp2 = FeatureSnapshot(**{**asdict(feat), "ts": "2026-01-01T00:00:20.000Z", "mid": 102.2, "best_bid": 102.15, "best_ask": 102.25})
    upd2 = exe.process_symbol(feat_tp2, {})
    assert_true(any(row[11] == "take_profit_2" for row in upd2.trade_rows), "TP2 full close must trigger")
    assert_true(len(exe.positions) == 0, "position should be fully closed after TP2")


def test_resolver_produces_signal() -> None:
    feat = make_feat()
    votes = generate_votes(feat)
    sig = Resolver().resolve(feat, votes)
    assert_true(sig.action == "long", f"expected long signal, got {sig.action}")


def test_feature_snapshot_non_empty() -> None:
    state = SymbolState(symbol="BTCUSDT")
    mid = 100.0
    state.bids = {99.99: 120.0, 99.98: 105.0, 99.97: 90.0}
    state.asks = {100.01: 80.0, 100.02: 75.0, 100.03: 70.0}
    state.price_history = [99.8 + i * 0.01 for i in range(120)]
    state.trade_window = [TradePrint(ts=f"2026-01-01T00:00:{i:02d}.000Z", price=mid, qty=5 + i * 0.1, side="buy_taker") for i in range(20)]
    state.updated_monotonic = 1.0
    feat = compute_feature_snapshot("BTCUSDT", state, "2026-01-01T00:00:30.000Z", 1.2)
    assert_true(feat is not None, "feature snapshot should be computed")
    assert_true(feat.spread_bps > 0, "spread should be positive")


if __name__ == "__main__":
    test_feature_snapshot_non_empty()
    test_resolver_produces_signal()
    test_execution_lifecycle()
    print("SMOKE TEST PASSED")
