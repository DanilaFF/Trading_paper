# START HERE — V4.1

## 1) Быстрая проверка логики
```bash
cd ~/Documents/trading_system_v41
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/smoke_test.py
```

## 2) Demo-режим
```bash
cd ~/Documents/trading_system_v41
bash launcher_demo.sh
```

## 3) Full stack

### Терминал 1
```bash
ollama serve
```

### Терминал 2
```bash
cd ~/clickhouse-test
./clickhouse server
```

### Терминал 3
```bash
cd ~/Documents/trading_system_v41
bash launcher_v41.sh
```

### Терминал 4 — проверки
```bash
curl http://127.0.0.1:8000/api/health | python3 -m json.tool
curl http://127.0.0.1:8000/api/open-positions | python3 -m json.tool
curl http://127.0.0.1:8000/api/recent-trades | python3 -m json.tool
```

### Терминал 5 — логи
```bash
tail -f /tmp/v41_engine.log
```
