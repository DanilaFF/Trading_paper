#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"
export MARKET_MODE=synthetic
export ENABLE_ORACLE=false
export SYMBOLS="BTCUSDT,ETHUSDT,SOLUSDT,BNBUSDT"
export FEATURE_INTERVAL_SECONDS="0.5"
export TABLE_SUFFIX="v41_demo"
exec "$ROOT_DIR/launcher_v41.sh"
