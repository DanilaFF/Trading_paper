CREATE TABLE IF NOT EXISTS orderbook_features_{suffix} (
    ts DateTime64(3, 'UTC'),
    symbol String,
    mid Float64,
    best_bid Float64,
    best_ask Float64,
    bid_qty_top Float64,
    ask_qty_top Float64,
    spread_bps Float64,
    imbalance Float64,
    wall_bid_share Float64,
    wall_ask_share Float64,
    depth_slope Float64,
    refill_ratio Float64,
    depletion_ratio Float64,
    trade_imbalance Float64,
    signed_volume Float64,
    toxicity Float64,
    sweep_score Float64,
    atr Float64,
    realized_vol Float64,
    hurst Float64,
    regime String,
    aggress_buy_qty Float64,
    aggress_sell_qty Float64,
    stale UInt8
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS agent_votes_{suffix} (
    ts DateTime64(3, 'UTC'),
    symbol String,
    agent String,
    vote String,
    score Float64,
    reason String,
    diagnostics_json String
) ENGINE = MergeTree
ORDER BY (symbol, agent, ts);

CREATE TABLE IF NOT EXISTS resolver_signals_{suffix} (
    ts DateTime64(3, 'UTC'),
    signal_id String,
    symbol String,
    action String,
    confidence Float64,
    long_score Float64,
    short_score Float64,
    reason String,
    regime String,
    hurst Float64,
    mid Float64,
    risk_state String
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS paper_orders_{suffix} (
    ts DateTime64(3, 'UTC'),
    order_id String,
    signal_id String,
    symbol String,
    side String,
    intent String,
    limit_price Float64,
    qty Float64,
    leverage Float64,
    notional_usdt Float64,
    state String,
    filled_qty Float64,
    avg_fill_price Float64,
    queue_ahead_qty Float64,
    ttl_seconds Float64,
    reason String
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS paper_fills_{suffix} (
    ts DateTime64(3, 'UTC'),
    order_id String,
    signal_id String,
    symbol String,
    side String,
    fill_price Float64,
    fill_qty Float64,
    fill_type String,
    slippage_bps Float64
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS paper_positions_{suffix} (
    ts DateTime64(3, 'UTC'),
    position_id String,
    symbol String,
    side String,
    qty Float64,
    leverage Float64,
    entry_price Float64,
    mark_price Float64,
    notional_usdt Float64,
    unrealized_pnl_usdt Float64,
    stop_price Float64,
    take_profit_price Float64,
    trailing_stop_price Float64,
    regime String,
    status String,
    entry_reason String
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS paper_trades_{suffix} (
    ts DateTime64(3, 'UTC'),
    trade_id String,
    position_id String,
    symbol String,
    side String,
    entry_price Float64,
    exit_price Float64,
    qty Float64,
    leverage Float64,
    gross_pnl_usdt Float64,
    net_pnl_usdt Float64,
    exit_reason String,
    hold_seconds Float64
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS portfolio_metrics_{suffix} (
    ts DateTime64(3, 'UTC'),
    balance_usdt Float64,
    realized_pnl_usdt Float64,
    total_leverage Float64,
    open_positions UInt32,
    drawdown_pct Float64,
    win_rate Float64,
    avg_win_usdt Float64,
    avg_loss_usdt Float64,
    pending_orders UInt32
) ENGINE = MergeTree
ORDER BY ts;

CREATE TABLE IF NOT EXISTS oracle_notes_{suffix} (
    ts DateTime64(3, 'UTC'),
    symbol String,
    note_type String,
    signal_id String,
    recommendation String,
    confidence Float64,
    analysis String,
    model String,
    tokens_used UInt32,
    ollama_latency_ms UInt32
) ENGINE = MergeTree
ORDER BY (symbol, ts);

CREATE TABLE IF NOT EXISTS system_events_{suffix} (
    ts DateTime64(3, 'UTC'),
    level String,
    component String,
    event_type String,
    symbol String,
    details String
) ENGINE = MergeTree
ORDER BY (component, ts);
